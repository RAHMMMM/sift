"use client";
import {useState} from 'react';
export default function Bench({counts}:{counts:{home:number;icons:number}}){
 const [result,setResult]=useState('Ready');
 async function scrollTest(){
  setResult('Running scroll test');
  for(let i=0;i<2;i++){(document.querySelector('.loadMoreWrap button') as HTMLButtonElement)?.click();await new Promise(r=>setTimeout(r,100))}
  await new Promise(r=>setTimeout(r,1500));
  const startCounts={...counts},frames:number[]=[],tasks:number[]=[];
  const observer=new PerformanceObserver(list=>list.getEntries().forEach(e=>tasks.push(e.duration)));
  observer.observe({type:'longtask',buffered:false});
  let start=performance.now(),last=start;
  await new Promise<void>(resolve=>{
   function step(now:number){
    frames.push(now-last);last=now;
    const progress=(now-start)/10000;
    window.scrollTo({top:(document.documentElement.scrollHeight-innerHeight)*(1-Math.cos(progress*Math.PI*4))/2,behavior:"instant"});
    if(progress<1)requestAnimationFrame(step);else resolve();
   }
   requestAnimationFrame(step);
  });
  observer.disconnect();frames.sort((a,b)=>a-b);
  setResult(JSON.stringify({test:'scroll',rows:document.querySelectorAll('tbody tr').length||document.querySelectorAll('.mobileTokenCard').length,homeRenders:counts.home-startCounts.home,iconRenders:counts.icons-startCounts.icons,frames:frames.length,p95ms:+frames[Math.floor(frames.length*.95)].toFixed(1),maxMs:+frames[frames.length-1].toFixed(1),longFrames:frames.filter(x=>x>33.4).length,longTasks:tasks.length,longTaskMs:+tasks.reduce((a,b)=>a+b,0).toFixed(1)}));
 }
 async function imageTest(){
  const count=()=>Array.from(document.querySelectorAll('.tokenIcon img')).filter(x=>(x as HTMLImageElement).naturalWidth>0).length;
  const before=count();setResult('Running image refresh test');
  (document.querySelector('.sectionTitle button') as HTMLButtonElement).click();
  await new Promise(r=>setTimeout(r,4000));
  setResult(JSON.stringify({test:'image-refresh',loadedBefore:before,loadedAfter:count()}));
 }
 return <div style={{position:'fixed',bottom:0,left:0,zIndex:9999,background:'#fff',color:'#000',padding:8}}><button onClick={scrollTest}>Run scroll test</button><button onClick={imageTest}>Run image refresh test</button><button onClick={()=>{const panel=document.querySelector<HTMLElement>('.marketPanel');if(!panel)return;const update=()=>{const box=panel.getBoundingClientRect();panel.style.clipPath=`inset(${Math.max(0,-box.top-256)}px -256px ${Math.max(0,box.bottom-innerHeight-256)}px -256px)`};window.addEventListener('scroll',update,{passive:true});update();setResult('Offscreen panel clipped')}}>Clip offscreen panel</button><button onClick={()=>{document.querySelectorAll<HTMLElement>('.ambientGrid,.ambientGlow').forEach(x=>x.style.willChange='transform');setResult('Background layers promoted')}}>Promote backgrounds</button><button onClick={()=>{document.querySelectorAll<HTMLElement>('.glassPanel').forEach(x=>x.style.willChange='transform');setResult('Panel layers promoted')}}>Promote panels</button><pre role="status">{result}</pre></div>
}
