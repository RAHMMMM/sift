"use client";
import { useEffect, useMemo, useRef, useState } from "react";

export const renderCounts={home:0,icons:0};

type W = { buys:number; sells:number; uniqueBuyers:number; buyVolume:string; sellVolume:string };
type Row = {
  token:string; curve:string; name:string; symbol:string; logo?:string; logoCandidates?:string[]; description?:string;
  score:number; heat:string; graduationProgress:number; creatorTaxBps:number; buyPressure5m:number; ageBlocks:number;
  tradeAcceleration:number; buyerAcceleration:number; reasons:string[];
  windows:{m5:W;m15:W;h1:W};
};
type Payload = { rows:Row[]; updatedAt:number; latestBlock?:string; stale:boolean; warning?:string; error?:string };
type Timeframe = "m5" | "m15" | "h1";

const short=(a:string)=>`${a.slice(0,6)}…${a.slice(-4)}`;
const trades=(w:W)=>w.buys+w.sells;
const signed=(n:number)=>`${n>0?"+":""}${n}%`;

function timeAgo(ts:number){if(!ts)return "";const s=Math.max(0,Math.round((Date.now()-ts)/1000));if(s<10)return "now";if(s<60)return `${s}s`;return `${Math.floor(s/60)}m`;}
function blockAge(blocks:number){const mins=Math.max(0,Math.round(blocks/60));if(mins<1)return "<1m";if(mins<60)return `${mins}m`;const h=Math.floor(mins/60);return h<24?`${h}h`:`${Math.floor(h/24)}d`;}
function formatBlock(v?:string){if(!v)return "";const n=Number(v);if(!Number.isFinite(n))return v;return n.toLocaleString();}

function TokenIcon({row,size="normal"}:{row:Row,size?:"normal"|"large"}){
  renderCounts.icons++;
  const candidates=row.logoCandidates?.length?row.logoCandidates:(row.logo?[row.logo]:[]);
  const [index,setIndex]=useState(0);
  const [visible,setVisible]=useState(size==="large");
  const ref=useRef<HTMLDivElement|null>(null);
  const timer=useRef<ReturnType<typeof setTimeout>|null>(null);

  useEffect(()=>{setIndex(0)},[row.token]);
  useEffect(()=>{
    if(size==="large"||visible||!candidates.length||!ref.current)return;
    const observer=new IntersectionObserver(([entry])=>{
      if(entry.isIntersecting){setVisible(true);observer.disconnect()}
    },{rootMargin:"320px 0px"});
    observer.observe(ref.current);
    return()=>observer.disconnect();
  },[visible,size,candidates.length]);
  useEffect(()=>{
    if(!visible||!candidates[index])return;
    if(timer.current)clearTimeout(timer.current);
    timer.current=setTimeout(()=>setIndex(i=>i+1),2800);
    return()=>{if(timer.current)clearTimeout(timer.current)};
  },[visible,index,candidates]);

  const src=visible?candidates[index]:undefined;
  const done=()=>{if(timer.current){clearTimeout(timer.current);timer.current=null}};
  const next=()=>{done();setIndex(i=>i+1)};
  return <div ref={ref} className={`tokenIcon ${src?"image":""} ${size}`}>{src?<img src={src} alt={`${row.symbol} token`} loading={size==="large"?"eager":"lazy"} fetchPriority={size==="large"?"high":"low"} decoding="async" referrerPolicy="no-referrer" onLoad={done} onError={next}/>:<span>{row.symbol.slice(0,2).toUpperCase()||"?"}</span>}</div>;
}
function Momentum({row}:{row:Row}){const rates=[trades(row.windows.h1)/60,trades(row.windows.m15)/15,trades(row.windows.m5)/5];const max=Math.max(...rates,.1);return <div className="momentum" title="Trade rate: 1h / 15m / 5m">{rates.map((v,i)=><i key={i} style={{height:`${Math.max(14,(v/max)*100)}%`}}/>)}</div>}
function ScoreRing({score}:{score:number}){return <div className="scoreRing" style={{"--score":`${score*3.6}deg`} as React.CSSProperties}><span>{score}</span></div>}
function Heat({value}:{value:string}){return <span className={`heat ${value.toLowerCase()}`}>{value}</span>}

export default function Home(){
  renderCounts.home++;
  const [payload,setPayload]=useState<Payload>({rows:[],updatedAt:0,stale:false});
  const [loading,setLoading]=useState(true);const [refreshing,setRefreshing]=useState(false);
  const [query,setQuery]=useState("");const [filter,setFilter]=useState("ALL");const [timeframe,setTimeframe]=useState<Timeframe>("m5");const [sort,setSort]=useState("score");
  const [selected,setSelected]=useState<Row|null>(null);const [error,setError]=useState("");const [copied,setCopied]=useState("");const [visibleCount,setVisibleCount]=useState(40);const [,setClock]=useState(0);

  async function load(manual=false){if(manual)setRefreshing(true);try{const r=await fetch("/api/trending",{cache:"no-store"});const d=await r.json();if(!r.ok)throw new Error(d.error||"Feed unavailable");setPayload(d);setError("");}catch(e){setError(e instanceof Error?e.message:"Feed unavailable")}finally{setLoading(false);setRefreshing(false)}}
  useEffect(()=>{load();const poll=setInterval(()=>load(),30000);const clock=setInterval(()=>setClock(x=>x+1),5000);return()=>{clearInterval(poll);clearInterval(clock)}},[]);
  useEffect(()=>{if(!selected)return;const onKey=(e:KeyboardEvent)=>e.key==="Escape"&&setSelected(null);window.addEventListener("keydown",onKey);return()=>window.removeEventListener("keydown",onKey)},[selected]);
  useEffect(()=>{setVisibleCount(40)},[query,filter,timeframe,sort]);

  const rows=useMemo(()=>payload.rows.filter(x=>{const q=query.trim().toLowerCase();return (!q||x.symbol.toLowerCase().includes(q)||x.name.toLowerCase().includes(q)||x.token.toLowerCase().includes(q))&&(filter==="ALL"||x.heat===filter)}).sort((a,b)=>{if(sort==="trades")return trades(b.windows[timeframe])-trades(a.windows[timeframe]);if(sort==="buyers")return b.windows[timeframe].uniqueBuyers-a.windows[timeframe].uniqueBuyers;if(sort==="pressure")return b.buyPressure5m-a.buyPressure5m;return b.score-a.score}),[payload.rows,query,filter,timeframe,sort]);
  const visibleRows=rows.slice(0,visibleCount);
  const signals=useMemo(()=>payload.rows.filter(x=>x.heat!=="QUIET").slice(0,3),[payload.rows]);
  const stats=useMemo(()=>({active:payload.rows.filter(x=>trades(x.windows.m5)>0).length,buyers:payload.rows.reduce((n,x)=>n+x.windows.m5.uniqueBuyers,0),heating:payload.rows.filter(x=>x.heat==="HEATING").length}),[payload.rows]);

  async function copyContract(address:string){try{await navigator.clipboard.writeText(address);setCopied(address);setTimeout(()=>setCopied(""),1300)}catch{}}
  const openMethod=()=>document.getElementById("method")?.scrollIntoView({behavior:"smooth"});

  return <main className="appShell">
    <div className="ambientGrid" aria-hidden="true"/><div className="ambientGlow glowA" aria-hidden="true"/><div className="ambientGlow glowB" aria-hidden="true"/>
    <header className="globalHeader glassBar">
      <div className="brandLock"><img src="/sift-logo.png" alt="SIFT"/><div><strong>SIFT</strong><span>MARKET INTELLIGENCE</span></div></div>
      <nav className="primaryNav"><button className="active">Market</button><button onClick={()=>document.getElementById("signals")?.scrollIntoView({behavior:"smooth"})}>Signals</button><button onClick={openMethod}>Method</button></nav>
      <div className="networkState" title={`Robinhood Chain · Block #${formatBlock(payload.latestBlock)}`}><span className={payload.stale?"dot amber":"dot"}/><b>{payload.stale?"STALE":"LIVE"}</b><em>synced {timeAgo(payload.updatedAt)} ago</em><span className="blockHint">Block #{payload.latestBlock?`${payload.latestBlock.slice(0,3)}.${payload.latestBlock.slice(3,4)}M`:""}</span></div>
    </header>

    <section className="workspace">
      <div className="marketHeader">
        <div className="heroCopy"><div className="eyebrow"><span>PONS ECONOMY</span><i/> LIVE MARKET</div><h1>Signal, <span>before consensus.</span></h1><p>SIFT ranks emerging Pons launches by buyer flow, trade velocity and market pressure while the move is still forming.</p></div>
        <div className="marketPulse glassPanel"><div><span>TRACKING</span><b>{payload.rows.length}</b></div><div><span>ACTIVE / 5M</span><b>{stats.active}</b></div><div><span>BUYERS / 5M</span><b>{stats.buyers}</b></div><div><span>HEATING</span><b className="accent">{stats.heating}</b></div></div>
      </div>

      <section className="signalDesk glassPanel" id="signals">
        <div className="sectionTitle"><div><span className="pulseDot"/>SIFT SIGNALS</div><p>Highest-conviction momentum shifts in the live discovery window</p><button onClick={()=>load(true)} disabled={refreshing}>{refreshing?"SYNCING…":"REFRESH"}</button></div>
        <div className="signalGrid">{(signals.length?signals:Array.from({length:3}).map(()=>null)).map((x,i)=>x?<button className="signalCard" key={x.token} onClick={()=>setSelected(x)}>
          <div className="signalTop"><span className="signalRank">0{i+1}</span><Heat value={x.heat}/><span className="ageTag">{blockAge(x.ageBlocks)}</span></div>
          <div className="signalAsset"><TokenIcon row={x} size="large"/><div><strong>${x.symbol}</strong><span>{x.name}</span></div><ScoreRing score={x.score}/></div>
          <div className="reasonList">{x.reasons.slice(0,2).map((r,j)=><span key={j}>{r}</span>)}</div>
          <div className="signalFoot"><span>BUY PRESSURE <b>{x.buyPressure5m}%</b></span><span>FLOW <b className={x.buyerAcceleration>0?"up":""}>{signed(x.buyerAcceleration)}</b></span><Momentum row={x}/></div>
        </button>:<div className="signalCard skeleton" key={i}><div/><div/><div/></div>)}</div>
      </section>

      <section className="marketPanel glassPanel">
        <div className="marketPanelHead"><div><h2>Market feed</h2><span>{rows.length} launches · updated {timeAgo(payload.updatedAt)} ago</span></div><div className="toolbar">
          <label className="search"><span>⌕</span><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Token, ticker or contract"/></label>
          <div className="tabs">{(["m5","m15","h1"] as Timeframe[]).map(t=><button key={t} className={timeframe===t?"active":""} onClick={()=>setTimeframe(t)}>{t==="m5"?"5M":t==="m15"?"15M":"1H"}</button>)}</div>
          <select value={filter} onChange={e=>setFilter(e.target.value)} aria-label="Filter by state"><option value="ALL">ALL STATES</option><option>HEATING</option><option>MOVING</option><option>EARLY</option><option>QUIET</option></select>
          <select value={sort} onChange={e=>setSort(e.target.value)} aria-label="Sort market"><option value="score">SIFT SCORE</option><option value="trades">TRADE RATE</option><option value="buyers">BUYERS</option><option value="pressure">PRESSURE</option></select>
        </div></div>
        {(payload.warning||error)&&<div className="notice">{payload.warning||error}</div>}
        <div className="desktopFeed tableScroller"><table className="marketTable"><thead><tr><th>ASSET</th><th>SIFT</th><th>STATE</th><th>FLOW</th><th>TRADES</th><th>BUYERS</th><th>PRESSURE</th><th>MOMENTUM</th><th>GRAD.</th><th>AGE</th><th></th></tr></thead><tbody>{visibleRows.map(x=>{const w=x.windows[timeframe];return <tr key={x.token} onClick={()=>setSelected(x)}>
          <td><div className="assetCell"><TokenIcon row={x}/><div><b>${x.symbol}</b><span>{x.name}</span></div></div></td><td><div className="scoreNum"><b>{x.score}</b><span>/100</span></div></td><td><Heat value={x.heat}/></td><td><span className={`delta ${x.tradeAcceleration>0?"positive":x.tradeAcceleration<0?"negative":""}`}>{signed(x.tradeAcceleration)}</span></td><td><b>{trades(w)}</b><span className="cellSub">{w.buys}B · {w.sells}S</span></td><td><b>{w.uniqueBuyers}</b></td><td><div className="pressureCell"><span>{x.buyPressure5m}%</span><div><i style={{width:`${x.buyPressure5m}%`}}/></div></div></td><td><Momentum row={x}/></td><td><div className="gradCell"><span>{x.graduationProgress.toFixed(0)}%</span><div><i style={{width:`${x.graduationProgress}%`}}/></div></div></td><td><span className="mono">{blockAge(x.ageBlocks)}</span></td><td><button className="rowArrow" aria-label="Open details">↗</button></td>
        </tr>})}</tbody></table></div>

        <div className="mobileFeed">{visibleRows.map(x=>{const w=x.windows[timeframe];return <button className="mobileTokenCard" key={x.token} onClick={()=>setSelected(x)}>
          <div className="mobileTokenTop"><div className="assetCell"><TokenIcon row={x}/><div><b>${x.symbol}</b><span>{x.name}</span></div></div><div className="mobileScore"><strong>{x.score}</strong><span>SIFT</span></div></div>
          <div className="mobileState"><Heat value={x.heat}/><span>{blockAge(x.ageBlocks)}</span><span className={x.tradeAcceleration>0?"positive":x.tradeAcceleration<0?"negative":""}>{signed(x.tradeAcceleration)} flow</span></div>
          <div className="mobileMetrics"><div><span>TRADES</span><b>{trades(w)}</b></div><div><span>BUYERS</span><b>{w.uniqueBuyers}</b></div><div><span>PRESSURE</span><b>{x.buyPressure5m}%</b></div><div><span>GRAD.</span><b>{x.graduationProgress.toFixed(0)}%</b></div></div>
          <div className="mobileBar"><i style={{width:`${x.buyPressure5m}%`}}/></div>
        </button>})}</div>
        {!loading&&visibleRows.length<rows.length&&<div className="loadMoreWrap"><button onClick={()=>setVisibleCount(v=>Math.min(v+30,rows.length))}>LOAD MORE <span>{rows.length-visibleRows.length}</span></button></div>}
        {loading&&<div className="emptyState"><span className="loaderDot"/> SYNCING ONCHAIN MARKET DATA</div>}{!loading&&!rows.length&&<div className="emptyState">NO LAUNCHES MATCH THIS VIEW</div>}
      </section>

      <section className="methodPanel glassPanel" id="method"><div><span>HOW SIFT READS THE MARKET</span><h3>Momentum, not hype.</h3></div><p>The SIFT Score blends trade acceleration, buyer acceleration, buy pressure, graduation velocity, graduation progress and freshness into a 0–100 momentum score. Signals are directional market intelligence, not financial advice.</p></section>
      <footer><div><img src="/sift-logo.png" alt=""/><b>SIFT</b></div><p>MARKET INTELLIGENCE FOR THE PONS ECONOMY</p><span>ROBINHOOD CHAIN · LIVE</span></footer>
    </section>

    {selected&&<div className="drawerBackdrop" onMouseDown={e=>{if(e.currentTarget===e.target)setSelected(null)}}><aside className="tokenDrawer glassDrawer">
      <button className="close" onClick={()=>setSelected(null)} aria-label="Close">×</button>
      <div className="drawerAsset"><TokenIcon row={selected} size="large"/><div><span>{selected.name}</span><h2>${selected.symbol}</h2><button onClick={()=>copyContract(selected.token)}>{short(selected.token)} · {copied===selected.token?"COPIED":"COPY"}</button></div></div>
      <div className="drawerScore"><ScoreRing score={selected.score}/><div><span>SIFT SCORE</span><strong>{selected.heat}</strong><p>{selected.reasons[0]||"Waiting for fresh flow"}</p></div></div>
      <div className="drawerGrid"><div><span>5M TRADES</span><b>{trades(selected.windows.m5)}</b></div><div><span>5M BUYERS</span><b>{selected.windows.m5.uniqueBuyers}</b></div><div><span>BUY PRESSURE</span><b>{selected.buyPressure5m}%</b></div><div><span>FLOW Δ</span><b className={selected.tradeAcceleration>0?"positive":selected.tradeAcceleration<0?"negative":""}>{signed(selected.tradeAcceleration)}</b></div><div><span>GRADUATION</span><b>{selected.graduationProgress.toFixed(1)}%</b></div><div><span>AGE</span><b>{blockAge(selected.ageBlocks)}</b></div></div>
      <div className="drawerReason"><span>WHY SIFT IS WATCHING</span>{selected.reasons.map((r,i)=><p key={i}><i>0{i+1}</i>{r}</p>)}</div>
      {selected.description&&<div className="drawerDescription"><span>ABOUT</span><p>{selected.description}</p></div>}
      <div className="drawerFoot">Live Pons market data · refreshed every 30 seconds</div>
    </aside></div>}
  </main>
}
