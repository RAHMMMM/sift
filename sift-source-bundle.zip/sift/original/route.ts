import { NextResponse } from "next/server";
import { client, curveAbi, factoryAbi, getRecentLaunches, tokenAbi, tokenInfoAbi, V2_FACTORY } from "@/lib/pons";
import { momentumScore, heatLabel } from "@/lib/score";
import { readWindowsForCurves, serializeWindow } from "@/lib/windows";
import { mapWithConcurrency, retry } from "@/lib/resilience";
import type { Address } from "viem";

export const dynamic = "force-dynamic";
const FEED_SIZE = Math.max(20, Math.min(120, Number(process.env.SIFT_FEED_SIZE || "100")));
const CACHE_TTL = 30_000;
let cache: { rows: any[]; updatedAt: number; latestBlock: string } | null = null;
let refreshing: Promise<{ rows:any[]; latestBlock:string }> | null = null;
const metadataCache = new Map<string, { name: string; symbol: string; logoCandidates: string[]; description:string; launch: any; at: number }>();

function logoCandidates(value: string) {
  const v = value.trim();
  if (!v) return [];
  if (v.startsWith("ipfs://")) {
    const hash = v.slice(7).replace(/^ipfs\//, "");
    return [
      `https://ipfs.io/ipfs/${hash}`,
      `https://dweb.link/ipfs/${hash}`,
      `https://w3s.link/ipfs/${hash}`,
      `https://gateway.pinata.cloud/ipfs/${hash}`,
    ];
  }
  if (v.startsWith("ar://")) return [`https://arweave.net/${v.slice(5)}`];
  if (/^https?:\/\//i.test(v)) return [v];
  // A few launchers store bare IPFS CIDs.
  if (/^(Qm[1-9A-HJ-NP-Za-km-z]{44}|bafy[a-zA-Z0-9]+)$/.test(v)) {
    return [`https://ipfs.io/ipfs/${v}`, `https://dweb.link/ipfs/${v}`, `https://w3s.link/ipfs/${v}`, `https://gateway.pinata.cloud/ipfs/${v}`];
  }
  return [];
}

function pct(n: bigint, d: bigint) {
  if (!d) return 0;
  return Math.max(0, Math.min(100, Number((n * 10000n) / d) / 100));
}

async function staticMetadata(token: Address) {
  const key = token.toLowerCase();
  const hit = metadataCache.get(key);
  if (hit) return hit;

  const [name, symbol, info, legacyLogo, launch] = await Promise.all([
    retry(() => client.readContract({ address: token, abi: tokenAbi, functionName: "name" }), { attempts: 2, timeoutMs: 8000 }),
    retry(() => client.readContract({ address: token, abi: tokenAbi, functionName: "symbol" }), { attempts: 2, timeoutMs: 8000 }),
    retry(() => client.readContract({ address: token, abi: tokenInfoAbi, functionName: "getTokenInfo" }), { attempts: 1, timeoutMs: 5500 }).catch(() => null),
    retry(() => client.readContract({ address: token, abi: tokenAbi, functionName: "logo" }), { attempts: 1, timeoutMs: 4500 }).catch(() => ""),
    retry(() => client.readContract({ address: V2_FACTORY, abi: factoryAbi, functionName: "getLaunchedToken", args: [token] }), { attempts: 2, timeoutMs: 8000 }),
  ]);

  let primaryLogo = "";
  let description = "";
  if (info && Array.isArray(info)) {
    primaryLogo = String(info[1] || "");
    description = String(info[2] || "");
  }
  const candidates = [...logoCandidates(primaryLogo), ...logoCandidates(String(legacyLogo || ""))]
    .filter((x, i, all) => all.indexOf(x) === i);

  const value = { name: String(name), symbol: String(symbol), logoCandidates: candidates, description, launch, at: Date.now() };
  metadataCache.set(key, value);
  return value;
}

function acceleration(now5:number, total15:number) {
  const prior10 = Math.max(0, total15 - now5);
  const prior5Rate = prior10 / 2;
  if (prior5Rate === 0) return now5 > 0 ? 100 : 0;
  return Math.round(((now5 - prior5Rate) / prior5Rate) * 100);
}

function reasons(windows:any, pressure:number, grad:number) {
  const t5 = windows.m5.buys + windows.m5.sells;
  const t15 = windows.m15.buys + windows.m15.sells;
  const tradeAccel = acceleration(t5, t15);
  const buyerAccel = acceleration(windows.m5.uniqueBuyers, windows.m15.uniqueBuyers);
  const out:string[] = [];
  if (tradeAccel >= 25) out.push(`Trade velocity +${tradeAccel}%`);
  if (buyerAccel >= 25) out.push(`Buyer flow +${buyerAccel}%`);
  if (pressure >= 68 && t5 >= 2) out.push(`${pressure}% buy pressure`);
  if (windows.m5.uniqueBuyers >= 3) out.push(`${windows.m5.uniqueBuyers} buyers / 5m`);
  if (grad >= 70 && grad < 100) out.push(`${grad.toFixed(0)}% to graduation`);
  if (!out.length && t5 > 0) out.push(`${t5} trades / 5m`);
  if (!out.length) out.push("Waiting for fresh flow");
  return { reasons: out.slice(0,3), tradeAcceleration: tradeAccel, buyerAcceleration: buyerAccel };
}

async function buildFeed() {
  const latest = await retry(() => client.getBlockNumber(), { attempts: 3, timeoutMs: 8000 });
  const launches = (await retry(() => getRecentLaunches(18_000n), { attempts: 3, timeoutMs: 12000 })).slice(0, FEED_SIZE);
  const curves = launches.map(x => x.curve);
  const launchBlocks = new Map(launches.map(x => [x.curve.toLowerCase(), x.blockNumber]));
  const windowMap = await retry(() => readWindowsForCurves(curves, launchBlocks, latest), { attempts: 2, timeoutMs: 15000 });

  const rows = await mapWithConcurrency(launches, 6, async launch => {
    try {
      const meta = await staticMetadata(launch.token);
      const windows = windowMap.get(launch.curve.toLowerCase());
      if (!windows) return null;
      let graduationProgress = Number(meta.launch.phase) >= 2 ? 100 : 0;
      try {
        const reserves = await retry(() => client.readContract({ address: launch.curve, abi: curveAbi, functionName: "getReserves" }), { attempts: 1, timeoutMs: 5000 });
        graduationProgress = pct(reserves[0], meta.launch.graduationThreshold);
      } catch {}
      const gradVelocity = windows.m5.buys * Math.max(0.2, graduationProgress / 100);
      const score = momentumScore({ ...windows, ageBlocks: Number(latest - launch.blockNumber), graduationProgress, graduationVelocity: gradVelocity });
      const trades5 = windows.m5.buys + windows.m5.sells;
      const buyPressure5m = trades5 ? Math.round((windows.m5.buys / trades5) * 100) : 0;
      const insight = reasons(windows, buyPressure5m, graduationProgress);
      return {
        token: launch.token,
        curve: launch.curve,
        name: meta.name,
        symbol: meta.symbol,
        logo: meta.logoCandidates[0] || "",
        logoCandidates: meta.logoCandidates,
        description: meta.description,
        score,
        heat: heatLabel(score, windows.m5, windows.m15),
        graduationProgress,
        creatorTaxBps: Number(meta.launch.creatorTaxBps),
        buyPressure5m,
        ageBlocks: Number(latest - launch.blockNumber),
        launchBlock: launch.blockNumber.toString(),
        tradeAcceleration: insight.tradeAcceleration,
        buyerAcceleration: insight.buyerAcceleration,
        reasons: insight.reasons,
        windows: { m5: serializeWindow(windows.m5), m15: serializeWindow(windows.m15), h1: serializeWindow(windows.h1) },
      };
    } catch { return null; }
  });
  return { rows: rows.sort((a: any, b: any) => b.score - a.score), latestBlock: latest.toString() };
}

export async function GET() {
  const now = Date.now();
  if (cache && now - cache.updatedAt < CACHE_TTL) return NextResponse.json({ ...cache, stale: false });
  try {
    refreshing ||= buildFeed().finally(() => { refreshing = null; });
    const built = await refreshing;
    if (built.rows.length) cache = { rows: built.rows, updatedAt: Date.now(), latestBlock: built.latestBlock };
    return NextResponse.json({ rows: cache?.rows || built.rows, updatedAt: cache?.updatedAt || Date.now(), latestBlock: cache?.latestBlock || built.latestBlock, stale: false });
  } catch (error) {
    if (cache) return NextResponse.json({ ...cache, stale: true, warning: "Live RPC refresh failed; showing last successful snapshot." });
    return NextResponse.json({ rows: [], error: error instanceof Error ? error.message : "Feed unavailable" }, { status: 503 });
  }
}
