const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),{performance}=require('node:perf_hooks');
const root='/Users/abdulwaheedabdulramon/Downloads/sift-v1.0-launch';const ts=require(root+'/node_modules/typescript');require(root+'/node_modules/@next/env').loadEnvConfig(root);
const modules=new Map();
function load(file){
 if(modules.has(file))return modules.get(file);
 let source=fs.readFileSync(file,'utf8');
 if(file.endsWith('/pons.ts'))source=source.replace(/transport: http\(process\.env\.ROBINHOOD_RPC_URL[\s\S]*?retryCount: 0,\n  }\),/,'transport: http(process.env.ROBINHOOD_RPC_URL || "https://rpc.mainnet.chain.robinhood.com"),');
 if(file.endsWith('route.ts'))source=source.replace('const CACHE_TTL = 30_000;','const CACHE_TTL = 0;');
 const api={};modules.set(file,api);
 vm.runInNewContext(ts.transpileModule(source,{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020}}).outputText,{exports:api,process,Date,Map,Set,Promise,setTimeout,clearTimeout,console,require:id=>id.startsWith('@/')?load(root+'/'+id.slice(2)+'.ts'):id.startsWith('.')?load(path.resolve(path.dirname(file),id)+'.ts'):require(root+'/node_modules/'+id)});
 return api;
}
(async()=>{
 const api=load(path.resolve('work/sift-original/route.ts'));
 for(const kind of ['cold','expired']){const start=performance.now();const response=await api.GET();const body=await response.json();console.log(JSON.stringify({version:'original',kind,http:response.status,ms:+(performance.now()-start).toFixed(1),rows:body.rows?.length}));}
})().catch(e=>console.log({error:e.name}));
