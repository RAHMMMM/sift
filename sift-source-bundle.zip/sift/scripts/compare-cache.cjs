const fs=require('node:fs'),vm=require('node:vm'),{performance}=require('node:perf_hooks');
const root='/Users/abdulwaheedabdulramon/Downloads/sift-v1.0-launch';const ts=require(root+'/node_modules/typescript');
async function run(file){
 let now=100000,jobs=[];const api={};const code=fs.readFileSync(file,'utf8')+'\nexport const setBuilder=(fn:any)=>{buildFeed=fn};';
 vm.runInNewContext(ts.transpileModule(code,{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020}}).outputText,{exports:api,process:{env:{}},Date:{now:()=>now},Map,Promise,require:id=>id==='next/server'?{NextResponse:{json:body=>body},after:fn=>jobs.push(fn)}:{}});
 api.setBuilder(async()=>{await new Promise(r=>setTimeout(r,250));return {rows:Array.from({length:100},(_,i)=>({token:String(i)})),latestBlock:'123'}});
 await api.GET();now+=31000;const start=performance.now();const response=await api.GET();const ms=performance.now()-start;await Promise.all(jobs.map(fn=>fn()));return {ms:+ms.toFixed(2),rows:response.rows.length,stale:response.stale};
}
(async()=>console.log(JSON.stringify({fixture:'identical 250ms refresh, expired populated cache',before:await run('work/sift-original/route.ts'),after:await run(root+'/app/api/trending/route.ts')})))();
