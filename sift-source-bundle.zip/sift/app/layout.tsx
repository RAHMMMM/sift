import "./globals.css";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "SIFT | Pons Market Intelligence",
  description: "Market intelligence for the Pons economy. Detect momentum before it becomes obvious.",
  icons: { icon: "/sift-logo.png", apple: "/sift-logo.png" },
  openGraph: {
    title: "SIFT | Pons Market Intelligence",
    description: "Detect momentum before it becomes obvious.",
    type: "website",
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
