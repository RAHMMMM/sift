import fixture from '../../../fixture.json';
export async function GET(req:Request){const row=fixture.rows.find(x=>x.token===new URL(req.url).searchParams.get('token'));return Response.json({logo:row?.logo||'',description:'Fixture token'})}
