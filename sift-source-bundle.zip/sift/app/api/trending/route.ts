import fixture from '../../../fixture.json';
export async function GET(){return Response.json({...fixture,updatedAt:Date.now(),stale:false})}
