"use client";
import Home, {renderCounts} from '../../components/before';
import Bench from '../../components/bench';
export default function Page(){return <><Home/><Bench counts={renderCounts}/></>}
