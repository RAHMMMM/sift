export type TokenMedia = { src: string; description: string };
export const MEDIA_DEADLINE_MS = 3000;
const cache = new Map<string, { value: TokenMedia; expires: number }>();
const pending = new Map<string, Promise<TokenMedia>>();
const queue: Array<() => void> = [];
let active = 0;

function drain() {
  while (active < 4 && queue.length) queue.shift()!();
}

function remember(key: string, value: TokenMedia) {
  cache.set(key, { value, expires: Date.now() + (value.src ? 3600000 : 300000) });
  if (cache.size > 512) cache.delete(cache.keys().next().value!);
}

export function rejectTokenImage(token: string) {
  const key = token.toLowerCase();
  remember(key, { src: '', description: cache.get(key)?.value.description || '' });
}

// One attempt per token, shared by cards and drawer. No gateway retry waterfall.
export function loadTokenMedia(token: string): Promise<TokenMedia> {
  const key = token.toLowerCase();
  const hit = cache.get(key);
  if (hit && hit.expires > Date.now()) return Promise.resolve(hit.value);
  const running = pending.get(key);
  if (running) return running;
  let complete!: (value: TokenMedia) => void;
  const result = new Promise<TokenMedia>(resolve => { complete = resolve; });
  pending.set(key, result);
  queue.push(() => {
    active++;
    const controller = new AbortController();
    let picture: HTMLImageElement | undefined;
    let settled = false;
    let description = '';
    const finish = (src = '') => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      controller.abort();
      if (picture) {
        picture.onload = null;
        picture.onerror = null;
        if (!src) picture.src = '';
      }
      const value = { src, description };
      remember(key, value);
      pending.delete(key);
      active--;
      complete(value);
      drain();
    };
    const timer = setTimeout(() => finish(), MEDIA_DEADLINE_MS);
    fetch(`/api/token-media?token=${encodeURIComponent(token)}`, { signal: controller.signal })
      .then(async response => {
        if (!response.ok) throw new Error('Media unavailable');
        const media = await response.json();
        if (settled) return;
        description = typeof media.description === 'string' ? media.description : '';
        if (typeof media.logo !== 'string' || !/^https?:\/\//i.test(media.logo)) return finish();
        picture = new Image();
        picture.decoding = 'async';
        picture.referrerPolicy = 'no-referrer';
        picture.onload = () => finish(media.logo);
        picture.onerror = () => finish();
        picture.src = media.logo;
      }).catch(() => finish());
  });
  drain();
  return result;
}
