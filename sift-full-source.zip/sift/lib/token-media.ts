import { createPublicClient, http, type Address } from 'viem';
import { robinhood, tokenAbi, tokenInfoAbi } from './pons';

// Media has its own transport and deadline; market refresh never awaits this client.
const mediaClient = createPublicClient({
  chain: robinhood,
  transport: http(process.env.ROBINHOOD_RPC_URL || 'https://rpc.mainnet.chain.robinhood.com', { timeout: 1800, retryCount: 0 }),
});
type Media = { logo: string; description: string };
const cache = new Map<string, { value: Media; expires: number }>();
const pending = new Map<string, Promise<Media>>();

export function mediaUrl(value: unknown): string {
  if (typeof value !== 'string') return '';
  const v = value.trim();
  if (v.startsWith('ipfs://')) return `https://ipfs.io/ipfs/${v.slice(7).replace(/^ipfs\//, '')}`;
  if (/^(Qm[1-9A-HJ-NP-Za-km-z]{44}|b[a-z2-7]{20,})(\/.*)?$/.test(v)) return `https://ipfs.io/ipfs/${v}`;
  if (v.startsWith('ar://')) return `https://arweave.net/${v.slice(5)}`;
  if (/^https?:\/\//i.test(v)) return v;
  return '';
}

export async function tokenMedia(token: Address): Promise<Media> {
  const key = token.toLowerCase();
  const hit = cache.get(key);
  if (hit && hit.expires > Date.now()) return hit.value;
  const running = pending.get(key);
  if (running) return running;
  const work = (async () => {
    const [info, legacy] = await Promise.all([
      mediaClient.readContract({ address: token, abi: tokenInfoAbi, functionName: 'getTokenInfo' }).catch(() => null),
      mediaClient.readContract({ address: token, abi: tokenAbi, functionName: 'logo' }).catch(() => ''),
    ]);
    const value = { logo: mediaUrl(info?.[1]) || mediaUrl(legacy), description: String(info?.[2] || '') };
    cache.set(key, { value, expires: Date.now() + (value.logo ? 3600000 : 300000) });
    if (cache.size > 512) cache.delete(cache.keys().next().value!);
    return value;
  })().finally(() => pending.delete(key));
  pending.set(key, work);
  return work;
}
