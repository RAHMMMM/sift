import type { AgentPost, AgentState } from "./agent-types";

export type FeedRow = {
  token: string; symbol: string; name: string; score: number; heat: string;
  buyPressure5m: number; tradeAcceleration: number; buyerAcceleration: number;
  graduationProgress: number; reasons?: string[];
  windows?: { m5?: { buys:number; sells:number; uniqueBuyers:number } };
};

function short(text: string, max = 280) {
  if (text.length <= max) return text;
  return text.slice(0, max - 1).trimEnd() + "…";
}

function tag(symbol: string) {
  const s = symbol.replace(/[^A-Za-z0-9_]/g, "");
  return s ? `$${s}` : symbol;
}

function pct(n: number) { return `${Math.round(n)}%`; }

function strongest(rows: FeedRow[], state: AgentState) {
  const now = Date.now();
  return rows.find(r => r.score >= 70 && (state.tokenCooldowns[r.token.toLowerCase()] || 0) < now);
}

export function generatePost(rows: FeedRow[], state: AgentState): AgentPost | null {
  if (!rows.length) return null;
  const kindIndex = state.runCount % 4;
  const top = strongest(rows, state) || rows[0];
  const id = crypto.randomUUID();
  const createdAt = Date.now();
  let kind: AgentPost["kind"] = "signal";
  let text = "";

  if (kindIndex === 0 && top.score >= 70) {
    kind = "signal";
    text = `SIFT SIGNAL\n\n${tag(top.symbol)} is showing one of the strongest live momentum profiles on Pons.\n\nSIFT ${top.score} ↑ · ${pct(top.buyPressure5m)} buy pressure · buyer flow ${top.buyerAcceleration >= 0 ? "+" : ""}${top.buyerAcceleration}% · graduation ${pct(top.graduationProgress)}\n\nSignal, not noise.`;
  } else if (kindIndex === 1) {
    kind = "board";
    const list = rows.slice(0, 5).map((r,i) => `${i+1}. ${tag(r.symbol)} · ${r.score}${r.score >= 80 ? " ↑" : ""}`).join("\n");
    text = `SIFT BOARD · Pons momentum now\n\n${list}\n\nRanked by live momentum signals, not market cap.`;
  } else if (kindIndex === 2) {
    kind = "pulse";
    const heating = rows.filter(r => r.score >= 85).length;
    const moving = rows.filter(r => r.score >= 70).length;
    const avgPressure = rows.length ? Math.round(rows.reduce((a,r)=>a+r.buyPressure5m,0)/rows.length) : 0;
    text = `Pons market pulse\n\n${rows.length} launches tracked · ${moving} moving · ${heating} heating\nAverage 5m buy pressure: ${avgPressure}%\n\nSIFT is filtering the live market for acceleration before it becomes obvious.`;
  } else {
    kind = "spotlight";
    const reason = top.reasons?.[0] || `${top.tradeAcceleration >= 0 ? "+" : ""}${top.tradeAcceleration}% trade acceleration`;
    text = `${tag(top.symbol)} is currently at SIFT ${top.score}.\n\nWhat stands out: ${reason.toLowerCase()}, ${pct(top.buyPressure5m)} buy pressure and ${pct(top.graduationProgress)} graduation progress.\n\nMomentum can change fast · SIFT tracks the shift in real time.`;
  }

  return { id, kind, text: short(text), status: "queued", createdAt, token: top.token, symbol: top.symbol, score: top.score };
}

export function generateReply(sourceText: string, sourceUrl: string, rows: FeedRow[]): AgentPost {
  const lower = sourceText.toLowerCase();
  const match = rows.find(r => lower.includes(`$${r.symbol.toLowerCase()}`) || lower.includes(r.name.toLowerCase()));
  let text: string;
  if (match) {
    text = `${tag(match.symbol)} is interesting on SIFT right now · score ${match.score}, ${pct(match.buyPressure5m)} 5m buy pressure and buyer flow ${match.buyerAcceleration >= 0 ? "+" : ""}${match.buyerAcceleration}%. The underlying momentum is the part worth watching.`;
  } else {
    const top = rows[0];
    text = top
      ? `Trending is the starting point. SIFT is watching what sits underneath it · buyer flow, trade acceleration and pressure. ${tag(top.symbol)} currently leads the live board at ${top.score}.`
      : `Trending is the starting point. The useful layer is what sits underneath it: buyer flow, trade acceleration and buy pressure.`;
  }
  return { id: crypto.randomUUID(), kind: "reply", text: short(text), status: "queued", createdAt: Date.now(), sourceTweetUrl: sourceUrl };
}
