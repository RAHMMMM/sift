const url = () => process.env.UPSTASH_REDIS_REST_URL?.replace(/\/$/, "");
const token = () => process.env.UPSTASH_REDIS_REST_TOKEN;

export function hasKv() { return Boolean(url() && token()); }

export async function redis<T = unknown>(command: Array<string | number>): Promise<T | null> {
  if (!hasKv()) throw new Error("Persistent index storage is not configured");
  const response = await fetch(url()!, {
    method: "POST",
    headers: { Authorization: `Bearer ${token()!}`, "Content-Type": "application/json" },
    body: JSON.stringify(command), cache: "no-store", signal: AbortSignal.timeout(8_000),
  });
  if (!response.ok) throw new Error(`Persistent index storage failed (${response.status})`);
  const body = await response.json() as { result?: T; error?: string };
  if (body.error) throw new Error("Persistent index storage rejected a command");
  return body.result ?? null;
}

export async function getJson<T>(key: string): Promise<T | null> {
  const raw = await redis<string>(["GET", key]);
  return raw ? JSON.parse(raw) as T : null;
}

export async function setJson(key: string, value: unknown, ttlSeconds?: number) {
  const command: Array<string | number> = ["SET", key, JSON.stringify(value)];
  if (ttlSeconds) command.push("EX", ttlSeconds);
  await redis(command);
}

export async function acquireLock(key: string, value: string, ttlSeconds: number) {
  return (await redis<string>(["SET", key, value, "NX", "EX", ttlSeconds])) === "OK";
}

export async function releaseLock(key: string, value: string) {
  if (await redis<string>(["GET", key]) === value) await redis(["DEL", key]);
}
