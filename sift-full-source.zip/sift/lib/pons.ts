import {
  createPublicClient,
  defineChain,
  http,
  parseAbi,
  parseAbiItem,
  type Address,
} from "viem";

export const robinhood = defineChain({
  id: 4663,
  name: "Robinhood Chain",
  nativeCurrency: { name: "Ether", symbol: "ETH", decimals: 18 },
  rpcUrls: {
    default: { http: [process.env.ROBINHOOD_RPC_URL || "https://rpc.mainnet.chain.robinhood.com"] },
  },
});

export const client = createPublicClient({
  chain: robinhood,
  transport: http(process.env.ROBINHOOD_RPC_URL || "https://rpc.mainnet.chain.robinhood.com", {
    timeout: 8000,
    batch: { batchSize: 100, wait: 10 },
    // Call sites own retries; avoid hidden transport retries outliving their deadlines.
    retryCount: 0,
  }),
});

export const V2_FACTORY = (
  process.env.PONS_V2_FACTORY || "0x7eD598BcEf8bd9Edd8C97A195C6d13f40801EC7e"
) as Address;

export const tokenLaunchedEvent = parseAbiItem(
  "event TokenLaunched(address indexed token, address indexed curve, address indexed deployer, address pairToken, uint256 launchConfigId, uint256 graduationThreshold)"
);

export const curveBuyEvent = parseAbiItem(
  "event CurveBuy(address indexed buyer, address indexed recipient, uint256 quoteIn, uint256 tokensOut, uint256 fee, uint256 tax)"
);

export const curveSellEvent = parseAbiItem(
  "event CurveSell(address indexed seller, address indexed recipient, uint256 tokensIn, uint256 quoteOut, uint256 fee, uint256 tax)"
);

export const tokenInfoAbi = parseAbi([
  "struct Socials { string twitter; string telegram; string discord; string website; string farcaster; }",
  "function getTokenInfo() view returns (address tokenDeployer, string tokenLogo, string tokenDescription, Socials tokenSocials)"
]);

export const tokenAbi = parseAbi([
  "function name() view returns (string)",
  "function symbol() view returns (string)",
  "function decimals() view returns (uint8)",
  "function totalSupply() view returns (uint256)",
  "function logo() view returns (string)",
  "function description() view returns (string)"
]);

export const curveAbi = parseAbi([
  "function getReserves() view returns (uint256 quoteReserve, uint256 tokenReserve)",
  "function sellableTokens() view returns (uint256)",
  "function feeBps() view returns (uint256)",
  "function creatorTaxBps() view returns (uint256)",
  "function pairToken() view returns (address)"
]);

export const factoryAbi = parseAbi([
  "struct LaunchedToken { address token; address curve; address deployer; address creatorFeeRecipient; address pairToken; uint256 graduationThreshold; uint24 poolFee; int24 tickSpacing; uint16 creatorTaxBps; bool buybackEnabled; uint8 phase; uint256 sweptQuote; uint256 sweptTokens; uint256 sweptAt; bool exists; }",
  "function getLaunchedToken(address token) view returns (LaunchedToken)"
]);

export type Launch = {
  token: Address;
  curve: Address;
  deployer: Address;
  pairToken: Address;
  blockNumber: bigint;
  transactionHash: string;
};

// Keep ranges bounded for provider reliability. Alchemy PAYG supports these
// production-sized ranges; its free tier is limited to 10 blocks and cannot
// sustain SIFT's rolling launch and trade-window index.
const LOG_BLOCK_SPAN = Number(process.env.RPC_LOG_BLOCK_SPAN || "2000");
let launchCache = new Map<string, Launch>();
let scannedToBlock: bigint | null = null;

async function readLaunchLogs(fromBlock: bigint, toBlock: bigint) {
  const requests = [];
  const last = Number(toBlock);
  for (let start = Number(fromBlock); start <= last; start += LOG_BLOCK_SPAN) {
    const end = Math.min(start + LOG_BLOCK_SPAN - 1, last);
    requests.push(client.getLogs({ address: V2_FACTORY, event: tokenLaunchedEvent, fromBlock: BigInt(start), toBlock: BigInt(end) }));
  }
  return (await Promise.all(requests)).flat();
}

export async function getRecentLaunches(blockLookback = 5000n, knownLatest?: bigint): Promise<Launch[]> {
  const latest = knownLatest ?? await client.getBlockNumber();
  const configured = BigInt(process.env.PONS_V2_DEPLOYMENT_BLOCK || "0");
  const fromBlock = latest > blockLookback ? latest - blockLookback : configured;
  const safeFromBlock = configured > fromBlock ? configured : fromBlock;

  let scanFrom = safeFromBlock;
  if (scannedToBlock !== null && scannedToBlock >= safeFromBlock) scanFrom = BigInt(Number(scannedToBlock) + 1);
  if (scanFrom <= latest) {
    const logs = await readLaunchLogs(scanFrom, latest);
    for (const log of logs) {
      const launch = {
        token: log.args.token!, curve: log.args.curve!, deployer: log.args.deployer!, pairToken: log.args.pairToken!,
        blockNumber: log.blockNumber, transactionHash: log.transactionHash,
      } satisfies Launch;
      launchCache.set(`${launch.transactionHash}:${log.logIndex}`, launch);
    }
    scannedToBlock = latest;
  }

  for (const [key, launch] of launchCache) if (launch.blockNumber < safeFromBlock) launchCache.delete(key);
  return [...launchCache.values()].sort((a, b) => {
    if (a.blockNumber > b.blockNumber) return -1;
    if (a.blockNumber < b.blockNumber) return 1;
    return 0;
  });
}
