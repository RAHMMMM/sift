import { acquireLock, getJson, releaseLock, setJson } from '@/lib/kv';
import { readSnapshot } from '@/lib/indexer';

const STATE_KEY = 'sift:signals:state:v1';
const LOCK_KEY = 'sift:signals:lock:v1';

export type SignalKind = 'MOMENTUM_BUILDING' | 'BUYER_SURGE' | 'GRADUATION_WATCH' | 'HEATING';
export type SignalMetrics = { score:number; buyers:number; trades:number; buyPressure:number; graduation:number; buyVolume:string; observedAt:number };
export type Observation = SignalMetrics & { token:string; symbol:string; name:string };
export type Signal = { token:string; symbol:string; name:string; kind:SignalKind; severity:number; confidence:number; current:Observation; previous:Observation; message:string };
type Delivered = { kind:SignalKind; severity:number; confidence:number; sentAt:number; metrics:SignalMetrics };
export type SignalState = { version:1; observations:Record<string,Observation>; delivered:Record<string,Delivered>; history:Array<{token:string;kind:SignalKind;sentAt:number;message:string}> };
type FeedRow = { token:string;symbol:string;name:string;score:number;buyPressure5m:number;graduationProgress:number;windows:{m5:{buys:number;sells:number;uniqueBuyers:number;buyVolume:string}} };

const emptyState=():SignalState=>({version:1,observations:{},delivered:{},history:[]});
const tag=(s:string)=>{const clean=s.replace(/[^A-Za-z0-9_]/g,'');return clean?`$${clean}`:s};
const n=(v:unknown)=>Number.isFinite(Number(v))?Number(v):0;
const metrics=(r:FeedRow,at:number):Observation=>({token:r.token,symbol:r.symbol,name:r.name,score:n(r.score),buyers:n(r.windows?.m5?.uniqueBuyers),trades:n(r.windows?.m5?.buys)+n(r.windows?.m5?.sells),buyPressure:n(r.buyPressure5m),graduation:n(r.graduationProgress),buyVolume:String(r.windows?.m5?.buyVolume||'0'),observedAt:at});
const line=(label:string,value:string)=>`${label.padEnd(16,' ')}${value}`;

export function renderSignal(kind:SignalKind,current:Observation,previous:Observation,baseUrl:string){
  const score=`${previous.score} → ${current.score}`,buyers=`${previous.buyers} → ${current.buyers}`;
  const common=[line('SIFT Score',score),line('Buyers / 5m',buyers),line('Buy Pressure',`${Math.round(current.buyPressure)}%`),line('Graduation',`${Math.round(current.graduation)}%`)].join('\n');
  const url=`${baseUrl.replace(/\/$/,'')}/?token=${encodeURIComponent(current.token)}`;
  if(kind==='BUYER_SURGE')return `Buyer activity is concentrating around ${tag(current.symbol)}.\n\nUnique buyers / 5m\n${buyers}\n\nSIFT Score: ${current.score}\nBuy Pressure: ${Math.round(current.buyPressure)}%\n\nParticipation expanded across the latest observation.\n\nView market → ${url}`;
  if(kind==='GRADUATION_WATCH')return `${tag(current.symbol)} has entered graduation watch.\n\n${common}\n\nGraduation progress is now accompanied by increasing market activity.\n\nView market → ${url}`;
  if(kind==='HEATING')return `${tag(current.symbol)} is heating.\n\n${common}\n\nMultiple momentum indicators accelerated together during the latest observation.\n\nView market → ${url}`;
  return `${tag(current.symbol)} is beginning to accelerate.\n\n${common}\n\nBuyer activity and momentum strengthened across the latest observation.\n\nView market → ${url}`;
}

export function detectSignal(row:FeedRow,previous:Observation|undefined,at=Date.now(),baseUrl='https://sift-pons.vercel.app'):Signal|null{
  if(!previous)return null;
  const current=metrics(row,at),scoreDelta=current.score-previous.score,buyerDelta=current.buyers-previous.buyers,tradeDelta=current.trades-previous.trades,gradDelta=current.graduation-previous.graduation;
  if(current.trades<3||current.buyers<2)return null;
  const confirms=[scoreDelta>=6,buyerDelta>=2,tradeDelta>=3,current.buyPressure>=62,gradDelta>=1].filter(Boolean).length;
  let kind:SignalKind|null=null,severity=1;
  if(current.score>=82&&scoreDelta>=10&&buyerDelta>=5&&tradeDelta>=8&&current.buyPressure>=62&&confirms>=4){kind='HEATING';severity=3;}
  else if(current.graduation>=65&&gradDelta>=1&&scoreDelta>=5&&buyerDelta>=2&&confirms>=3){kind='GRADUATION_WATCH';severity=2;}
  else if(current.buyers>=5&&buyerDelta>=4&&current.buyers>=Math.max(5,previous.buyers*1.6)&&tradeDelta>=3&&confirms>=3)kind='BUYER_SURGE';
  else if(scoreDelta>=7&&buyerDelta>=2&&tradeDelta>=3&&confirms>=3)kind='MOMENTUM_BUILDING';
  if(!kind)return null;
  const confidence=Math.min(100,45+confirms*8+Math.min(15,Math.max(0,scoreDelta))+Math.min(12,Math.max(0,buyerDelta))+(severity-1)*5);
  const signal={token:current.token,symbol:current.symbol,name:current.name,kind,severity,confidence,current,previous,message:''} satisfies Signal;
  signal.message=renderSignal(kind,current,previous,baseUrl);return signal;
}

export function shouldSuppress(signal:Signal,last:Delivered|undefined,at:number,cooldown:number){return Boolean(last&&at-last.sentAt<cooldown&&!(signal.severity>last.severity&&signal.confidence>=80));}

async function sendTelegram(text:string){
  const token=process.env.TELEGRAM_BOT_TOKEN,chatId=process.env.TELEGRAM_CHAT_ID,threadId=Number(process.env.TELEGRAM_SIGNAL_THREAD_ID);
  if(!token||!chatId||!Number.isInteger(threadId)||threadId<=0)throw new Error('Telegram bot, chat, or Signals topic is not configured');
  const response=await fetch(`https://api.telegram.org/bot${token}/sendMessage`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({chat_id:chatId,message_thread_id:threadId,text,disable_web_page_preview:false}),signal:AbortSignal.timeout(12_000)});
  const body=await response.json().catch(()=>({}));
  if(!response.ok||!body.ok)throw new Error(`Telegram rejected the message (${response.status})`);
  return body.result?.message_id as number|undefined;
}

export async function runSignalEvaluation(){
  const lock=crypto.randomUUID();if(!await acquireLock(LOCK_KEY,lock,55))return {ok:true,skipped:true,reason:'RUN_IN_PROGRESS'};
  try{
    const snapshot=await readSnapshot();if(!snapshot||snapshot.stale||!snapshot.rows?.length)throw new Error('A fresh indexed market snapshot is not available');
    const state=await getJson<SignalState>(STATE_KEY)||emptyState(),at=Date.now(),baseUrl=process.env.SIFT_PUBLIC_URL||'https://sift-pons.vercel.app';
    const dryRun=process.env.SIGNALS_LIVE!=='true'&&process.env.SIGNALS_DRY_RUN!=='false',cooldown=Number(process.env.SIGNALS_TOKEN_COOLDOWN_MINUTES||'45')*60_000,maxPerRun=Math.max(1,Math.min(5,Number(process.env.SIGNALS_MAX_PER_RUN||'2')));
    const detected:Signal[]=[],suppressed:Array<{token:string;reason:string}>=[],errors:string[]=[];
    for(const row of snapshot.rows as FeedRow[]){const key=row.token.toLowerCase(),prev=state.observations[key],signal=detectSignal(row,prev,at,baseUrl);if(signal){const last=state.delivered[key];if(shouldSuppress(signal,last,at,cooldown))suppressed.push({token:row.token,reason:'COOLDOWN'});else detected.push(signal);}else suppressed.push({token:row.token,reason:prev?'INSUFFICIENT_ACCELERATION':'MISSING_DATA'});state.observations[key]=metrics(row,at);}
    detected.sort((a,b)=>b.severity-a.severity||b.confidence-a.confidence);let sent=0;
    for(const signal of detected.slice(0,maxPerRun)){if(dryRun)continue;try{await sendTelegram(signal.message);sent++;state.delivered[signal.token.toLowerCase()]={kind:signal.kind,severity:signal.severity,confidence:signal.confidence,sentAt:at,metrics:signal.current};state.history.unshift({token:signal.token,kind:signal.kind,sentAt:at,message:signal.message});}catch(e){errors.push(e instanceof Error?e.message:'Telegram send failed');}}
    state.history=state.history.slice(0,200);await setJson(STATE_KEY,state);
    return {ok:true,dryRun,marketsChecked:snapshot.rows.length,signalsDetected:detected.length,signalsSuppressed:suppressed.length,telegramSent:sent,candidates:detected.slice(0,maxPerRun).map(x=>({token:x.token,symbol:x.symbol,type:x.kind,severity:x.severity,confidence:x.confidence,message:x.message})),suppressionReasons:suppressed.reduce<Record<string,number>>((a,x)=>(a[x.reason]=(a[x.reason]||0)+1,a),{}),errors};
  }finally{await releaseLock(LOCK_KEY,lock).catch(()=>{});}
}

export async function sendTelegramTest(){return sendTelegram('SIFT Signals connected.\n\nMarket monitoring is online.');}
