export type AgentPostStatus = "queued" | "posted" | "skipped" | "failed";

export type AgentPost = {
  id: string;
  kind: "signal" | "board" | "pulse" | "spotlight" | "reply";
  text: string;
  status: AgentPostStatus;
  createdAt: number;
  postedAt?: number;
  tweetId?: string;
  token?: string;
  symbol?: string;
  score?: number;
  sourceTweetUrl?: string;
  error?: string;
};

export type AgentState = {
  version: 1;
  enabled: boolean;
  runCount: number;
  lastRunAt: number | null;
  lastPostAt: number | null;
  lastResult: string | null;
  posts: AgentPost[];
  tokenCooldowns: Record<string, number>;
};
