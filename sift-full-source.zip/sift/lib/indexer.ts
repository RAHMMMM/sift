import type { Address } from "viem";
import { client, curveAbi, curveBuyEvent, curveSellEvent, factoryAbi, tokenAbi, tokenLaunchedEvent, V2_FACTORY } from "@/lib/pons";
import { acquireLock, getJson, releaseLock, setJson } from "@/lib/kv";
import { heatLabel, momentumScore, type WindowStats } from "@/lib/score";
import { retry } from "@/lib/resilience";

const PREFIX = "sift:v2";
const STATE_KEY = `${PREFIX}:state`, DATA_KEY = `${PREFIX}:data`;
export const SNAPSHOT_KEY = `${PREFIX}:snapshot`;
const LOCK_KEY = `${PREFIX}:lock`, RANGE = 10, MAX_RANGES = 8, MAX_LIVE_RANGES = 75, MAX_BACKFILL_RANGES = 120, RECENT_BOOTSTRAP = 600;
const BPM = Number(process.env.RADAR_BLOCKS_PER_MINUTE || "600");
const UNIVERSE_SIZE = Math.max(100, Math.min(1000, Number(process.env.SIFT_UNIVERSE_SIZE || "500")));
const FEED_SIZE = Math.max(20, Math.min(120, Number(process.env.SIFT_FEED_SIZE || "100")));
const MAX_LOOKBACK = Math.max(BPM*60, Number(process.env.SIFT_DISCOVERY_LOOKBACK_BLOCKS || String(BPM*6*60)));

type Phase = "recent" | "launches" | "trades" | "ready";
type IndexState = { version:8; phase:Phase; initializedHead:number; latestHead:number; liveCursor:number; recentTarget:number; launchBackfillCursor:number; launchBackfillFloor:number; tradeRebuildCursor:number; reserveCursor:number; updatedAt:number };
type IndexedLaunch = { token:Address; curve:Address; deployer:Address; pairToken:Address; blockNumber:number; transactionHash:string; name?:string; symbol?:string; graduationThreshold?:string; creatorTaxBps?:number; phase?:number; quoteReserve?:string };
type IndexedTrade = { id:string; curve:string; blockNumber:number; side:"buy"|"sell"; buyer?:string; quote:string };
type IndexData = { launches:IndexedLaunch[]; trades:IndexedTrade[] };
export type FeedSnapshot = { rows:any[]; updatedAt:number; latestBlock:string; stale:boolean; warning?:string; bootstrap:{phase:Phase;complete:boolean;indexedThrough:number;target:number}; diagnostics:{rpcRequestsLastRefresh:number;indexedRanges:number} };

let rpcRequests = 0;
const sleep = (ms:number) => new Promise(resolve => setTimeout(resolve, ms));
const rpc = async <T>(fn:()=>Promise<T>) => { rpcRequests++; return retry(fn, { attempts:2, delayMs:450, timeoutMs:8_000 }); };

function initialState(head:number):IndexState {
  const deployment=Number(process.env.PONS_V2_DEPLOYMENT_BLOCK||"0"), start=Math.max(deployment,head-RECENT_BOOTSTRAP+1);
  return {version:8,phase:"recent",initializedHead:head,latestHead:head,liveCursor:start,recentTarget:head,launchBackfillCursor:start-1,launchBackfillFloor:Math.max(deployment,head-MAX_LOOKBACK+1),tradeRebuildCursor:start-1,reserveCursor:0,updatedAt:Date.now()};
}
const launchKey=(x:IndexedLaunch)=>`${x.transactionHash}:${x.token.toLowerCase()}`;
async function launchLogs(from:number,to:number){return rpc(()=>client.getLogs({address:V2_FACTORY,event:tokenLaunchedEvent,fromBlock:BigInt(from),toBlock:BigInt(to)}));}
async function tradeLogs(curves:Address[],from:number,to:number){
  if(!curves.length)return [] as IndexedTrade[];
  const logs=await rpc(()=>client.getLogs({address:curves,events:[curveBuyEvent,curveSellEvent],fromBlock:BigInt(from),toBlock:BigInt(to)}));
  return decodeTradeLogs(logs);
}
function decodeTradeLogs(logs:any[]):IndexedTrade[]{return logs.map(log=>log.eventName==="CurveBuy"
    ? {id:`${log.transactionHash}:${log.logIndex}`,curve:log.address.toLowerCase(),blockNumber:Number(log.blockNumber),side:"buy" as const,buyer:String(log.args.buyer||"").toLowerCase(),quote:String(log.args.quoteIn||0n)}
    : {id:`${log.transactionHash}:${log.logIndex}`,curve:log.address.toLowerCase(),blockNumber:Number(log.blockNumber),side:"sell" as const,quote:String(log.args.quoteOut||0n)});}
function mergeLaunches(existing:IndexedLaunch[],incoming:IndexedLaunch[]){const map=new Map(existing.map(x=>[launchKey(x),x]));for(const x of incoming)map.set(launchKey(x),{...map.get(launchKey(x)),...x});return [...map.values()].sort((a,b)=>b.blockNumber-a.blockNumber).slice(0,UNIVERSE_SIZE);}
function mergeTrades(existing:IndexedTrade[],incoming:IndexedTrade[],head:number){const floor=head-BPM*60,map=new Map(existing.filter(x=>x.blockNumber>=floor).map(x=>[x.id,x]));for(const x of incoming)if(x.blockNumber>=floor)map.set(x.id,x);return [...map.values()];}
function decodeLaunchLogs(logs:Awaited<ReturnType<typeof launchLogs>>):IndexedLaunch[]{return logs.map(log=>({token:log.args.token!,curve:log.args.curve!,deployer:log.args.deployer!,pairToken:log.args.pairToken!,blockNumber:Number(log.blockNumber),transactionHash:log.transactionHash}));}

async function enrichLaunches(data:IndexData,limit=3){
  for(const launch of data.launches.filter(x=>!x.name||!x.graduationThreshold).slice(0,limit))try{
    const [name,symbol,factory]=await Promise.all([rpc(()=>client.readContract({address:launch.token,abi:tokenAbi,functionName:"name"})),rpc(()=>client.readContract({address:launch.token,abi:tokenAbi,functionName:"symbol"})),rpc(()=>client.readContract({address:V2_FACTORY,abi:factoryAbi,functionName:"getLaunchedToken",args:[launch.token]}))]);
    launch.name=String(name);launch.symbol=String(symbol);launch.graduationThreshold=String(factory.graduationThreshold);launch.creatorTaxBps=Number(factory.creatorTaxBps);launch.phase=Number(factory.phase);
  }catch{}
}
async function refreshReserves(data:IndexData,state:IndexState,limit=5){if(!data.launches.length)return;for(let i=0;i<Math.min(limit,data.launches.length);i++){const x=data.launches[(state.reserveCursor+i)%data.launches.length];try{x.quoteReserve=String((await rpc(()=>client.readContract({address:x.curve,abi:curveAbi,functionName:"getReserves"})))[0]);}catch{}}state.reserveCursor=(state.reserveCursor+limit)%data.launches.length;}
const empty=():WindowStats=>({buys:0,sells:0,uniqueBuyers:0,buyVolume:0n,sellVolume:0n});
function windowsFor(curve:string,trades:IndexedTrade[],head:number){const windows={m5:empty(),m15:empty(),h1:empty()},buyers={m5:new Set<string>(),m15:new Set<string>(),h1:new Set<string>()},cuts={m5:head-BPM*5,m15:head-BPM*15,h1:head-BPM*60};for(const t of trades){if(t.curve!==curve)continue;for(const k of ["m5","m15","h1"] as const){if(t.blockNumber<cuts[k])continue;const w=windows[k];if(t.side==="buy"){w.buys++;w.buyVolume+=BigInt(t.quote);if(t.buyer)buyers[k].add(t.buyer);}else{w.sells++;w.sellVolume+=BigInt(t.quote);}}}for(const k of ["m5","m15","h1"] as const)windows[k].uniqueBuyers=buyers[k].size;return windows;}
const serialized=(w:WindowStats)=>({...w,buyVolume:w.buyVolume.toString(),sellVolume:w.sellVolume.toString()});
function acceleration(now5:number,total15:number){if(now5===0)return 0;const prior=Math.max(0,total15-now5)/2;return prior===0?100:Math.round((now5-prior)/prior*100);}
function buildSnapshot(data:IndexData,state:IndexState,indexedRanges:number):FeedSnapshot{
  const allRows=data.launches.flatMap(x=>{if(!x.name||!x.symbol||!x.graduationThreshold)return[];const w=windowsFor(x.curve.toLowerCase(),data.trades,state.latestHead),threshold=BigInt(x.graduationThreshold),reserve=BigInt(x.quoteReserve||"0"),graduationProgress=(x.phase||0)>=2?100:threshold?Math.max(0,Math.min(100,Number(reserve*10000n/threshold)/100)):0,ageBlocks=Math.max(0,state.latestHead-x.blockNumber),scoreAgeBlocks=Math.round(ageBlocks*60/BPM),score=momentumScore({...w,ageBlocks:scoreAgeBlocks,graduationProgress,graduationVelocity:w.m5.buys*Math.max(.2,graduationProgress/100)}),trades5=w.m5.buys+w.m5.sells,buyPressure5m=trades5?Math.round(w.m5.buys/trades5*100):0,tradeAcceleration=acceleration(trades5,w.m15.buys+w.m15.sells),buyerAcceleration=acceleration(w.m5.uniqueBuyers,w.m15.uniqueBuyers),reasons:string[]=[];if(tradeAcceleration>=25)reasons.push(`Trade velocity +${tradeAcceleration}%`);if(buyerAcceleration>=25)reasons.push(`Buyer flow +${buyerAcceleration}%`);if(buyPressure5m>=68&&trades5>=2)reasons.push(`${buyPressure5m}% buy pressure`);if(!reasons.length&&trades5)reasons.push(`${trades5} trades / 5m`);if(!reasons.length)reasons.push("Waiting for fresh flow");return[{token:x.token,curve:x.curve,name:x.name,symbol:x.symbol,score,heat:heatLabel(score,w.m5,w.m15),graduationProgress,creatorTaxBps:x.creatorTaxBps||0,buyPressure5m,ageBlocks,launchBlock:String(x.blockNumber),tradeAcceleration,buyerAcceleration,reasons:reasons.slice(0,3),windows:{m5:serialized(w.m5),m15:serialized(w.m15),h1:serialized(w.h1)}}];}).sort((a,b)=>b.score-a.score);
  const useful=allRows.filter(x=>x.windows.h1.buys+x.windows.h1.sells>0||x.graduationProgress>0);const rows=(useful.length>=20?useful:allRows).slice(0,FEED_SIZE);
  const complete=state.phase==="ready",target=state.phase==="recent"?state.recentTarget:state.latestHead;return{rows,updatedAt:Date.now(),latestBlock:String(state.latestHead),stale:false,warning:complete?undefined:`Indexing onchain history · ${state.phase} bootstrap in progress`,bootstrap:{phase:state.phase,complete,indexedThrough:state.liveCursor-1,target},diagnostics:{rpcRequestsLastRefresh:rpcRequests,indexedRanges}};
}
async function scanForwardRange(data:IndexData,from:number,to:number,includeTrades=true){
  const knownCurves=data.launches.map(x=>x.curve),addresses=[V2_FACTORY,...knownCurves];
  const logs:any[]=await rpc(()=>client.getLogs({address:addresses,events:[tokenLaunchedEvent,curveBuyEvent,curveSellEvent],fromBlock:BigInt(from),toBlock:BigInt(to)} as any));
  const launched=decodeLaunchLogs(logs.filter(log=>log.eventName==="TokenLaunched") as any);
  data.launches=mergeLaunches(data.launches,launched);
  if(includeTrades){
    let trades=decodeTradeLogs(logs.filter(log=>log.eventName==="CurveBuy"||log.eventName==="CurveSell"));
    if(launched.length)trades=trades.concat(await tradeLogs(launched.map(x=>x.curve),from,to));
    data.trades=mergeTrades(data.trades,trades,to);
  }
}

export async function advanceIndex():Promise<FeedSnapshot|null>{
  const lockValue=crypto.randomUUID();if(!await acquireLock(LOCK_KEY,lockValue,55))return getJson<FeedSnapshot>(SNAPSHOT_KEY);rpcRequests=0;let indexedRanges=0;
  try{const head=Number(await rpc(()=>client.getBlockNumber()));let state=await getJson<IndexState>(STATE_KEY),data=await getJson<IndexData>(DATA_KEY);if(!state||state.version!==8){state=initialState(head);data={launches:data?.launches||[],trades:data?.trades||[]};if(data.launches.length>=20){state.phase="trades";state.liveCursor=head+1;state.tradeRebuildCursor=head;}}if(!data)data={launches:[],trades:[]};state.latestHead=head;
    let liveRanges=0,backfillRanges=0;
    if(state.phase!=="recent")while(liveRanges<MAX_LIVE_RANGES&&state.liveCursor<=head){const to=Math.min(state.liveCursor+RANGE-1,head);await scanForwardRange(data,state.liveCursor,to,true);state.liveCursor=to+1;liveRanges++;indexedRanges++;await sleep(250);}
    if(state.phase==="recent"){while(liveRanges<MAX_LIVE_RANGES&&state.liveCursor<=state.recentTarget){const to=Math.min(state.liveCursor+RANGE-1,state.recentTarget);await scanForwardRange(data,state.liveCursor,to,true);state.liveCursor=to+1;liveRanges++;indexedRanges++;await sleep(250);}if(state.liveCursor>state.recentTarget)state.phase="launches";}
    else if(state.phase==="launches"&&state.liveCursor>head){for(let i=0;i<MAX_RANGES&&state.launchBackfillCursor>=state.launchBackfillFloor&&data.launches.length<UNIVERSE_SIZE;i++){const to=state.launchBackfillCursor,from=Math.max(state.launchBackfillFloor,to-RANGE+1);data.launches=mergeLaunches(data.launches,decodeLaunchLogs(await launchLogs(from,to)));state.launchBackfillCursor=from-1;indexedRanges++;await sleep(650);}if(data.launches.length>=20){state.phase="trades";state.tradeRebuildCursor=head;}}
    else if(state.phase==="trades"&&state.liveCursor>head){const floor=Math.max(0,head-BPM*60+1);while(backfillRanges<MAX_BACKFILL_RANGES&&state.tradeRebuildCursor>=floor){const to=state.tradeRebuildCursor,from=Math.max(floor,to-RANGE+1);data.trades=mergeTrades(data.trades,await tradeLogs(data.launches.map(x=>x.curve),from,to),head);state.tradeRebuildCursor=from-1;backfillRanges++;indexedRanges++;await sleep(250);}if(state.tradeRebuildCursor<floor)state.phase="ready";}
    else if(state.phase==="ready"&&state.liveCursor>head&&state.launchBackfillCursor>=state.launchBackfillFloor&&data.launches.length<UNIVERSE_SIZE){for(let i=0;i<MAX_RANGES&&state.launchBackfillCursor>=state.launchBackfillFloor;i++){const to=state.launchBackfillCursor,from=Math.max(state.launchBackfillFloor,to-RANGE+1);data.launches=mergeLaunches(data.launches,decodeLaunchLogs(await launchLogs(from,to)));state.launchBackfillCursor=from-1;indexedRanges++;await sleep(650);}}
    await enrichLaunches(data);await refreshReserves(data,state);data.trades=mergeTrades(data.trades,[],head);state.updatedAt=Date.now();const snapshot=buildSnapshot(data,state,indexedRanges);await Promise.all([setJson(STATE_KEY,state),setJson(DATA_KEY,data),setJson(SNAPSHOT_KEY,snapshot)]);return snapshot;
  }finally{await releaseLock(LOCK_KEY,lockValue).catch(()=>{});}
}
export async function readSnapshot(){return getJson<FeedSnapshot>(SNAPSHOT_KEY);}
