import crypto from "node:crypto";

function enc(v: string) {
  return encodeURIComponent(v).replace(/[!'()*]/g, c => `%${c.charCodeAt(0).toString(16).toUpperCase()}`);
}

function oauthHeader(method: string, url: string) {
  const consumerKey = process.env.X_API_KEY || "";
  const consumerSecret = process.env.X_API_SECRET || "";
  const token = process.env.X_ACCESS_TOKEN || "";
  const tokenSecret = process.env.X_ACCESS_SECRET || "";
  if (!consumerKey || !consumerSecret || !token || !tokenSecret) {
    throw new Error("X credentials are not configured");
  }
  const params: Record<string,string> = {
    oauth_consumer_key: consumerKey,
    oauth_nonce: crypto.randomBytes(16).toString("hex"),
    oauth_signature_method: "HMAC-SHA1",
    oauth_timestamp: Math.floor(Date.now()/1000).toString(),
    oauth_token: token,
    oauth_version: "1.0",
  };
  const paramString = Object.entries(params).sort(([a],[b]) => a.localeCompare(b)).map(([k,v]) => `${enc(k)}=${enc(v)}`).join("&");
  const base = `${method.toUpperCase()}&${enc(url)}&${enc(paramString)}`;
  const key = `${enc(consumerSecret)}&${enc(tokenSecret)}`;
  params.oauth_signature = crypto.createHmac("sha1", key).update(base).digest("base64");
  return "OAuth " + Object.entries(params).sort(([a],[b]) => a.localeCompare(b)).map(([k,v]) => `${enc(k)}="${enc(v)}"`).join(", ");
}

export function xConfigured() {
  return Boolean(process.env.X_API_KEY && process.env.X_API_SECRET && process.env.X_ACCESS_TOKEN && process.env.X_ACCESS_SECRET);
}

export async function createTweet(text: string, replyToId?: string) {
  const url = "https://api.x.com/2/tweets";
  const body: any = { text };
  if (replyToId) body.reply = { in_reply_to_tweet_id: replyToId };
  const res = await fetch(url, {
    method: "POST",
    headers: { Authorization: oauthHeader("POST", url), "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  const json = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(json?.detail || json?.title || json?.errors?.[0]?.message || `X API ${res.status}`);
  return json.data as { id: string; text: string };
}

export function tweetIdFromUrl(url: string) {
  const m = url.match(/status\/(\d+)/);
  return m?.[1] || "";
}
