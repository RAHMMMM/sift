import type { AgentState } from "./agent-types";

const KEY = "sift:agent:state:v1";
const DEFAULT_STATE: AgentState = {
  version: 1,
  enabled: true,
  runCount: 0,
  lastRunAt: null,
  lastPostAt: null,
  lastResult: null,
  posts: [],
  tokenCooldowns: {},
};

declare global {
  // eslint-disable-next-line no-var
  var __siftAgentState: AgentState | undefined;
}

function clone<T>(value: T): T { return JSON.parse(JSON.stringify(value)); }

async function redis(command: string[]) {
  const url = process.env.UPSTASH_REDIS_REST_URL;
  const token = process.env.UPSTASH_REDIS_REST_TOKEN;
  if (!url || !token) return null;
  const res = await fetch(`${url}/${command.map(encodeURIComponent).join("/")}`, {
    headers: { Authorization: `Bearer ${token}` },
    cache: "no-store",
  });
  if (!res.ok) throw new Error(`Redis ${res.status}`);
  return res.json();
}

export function storageMode() {
  return process.env.UPSTASH_REDIS_REST_URL && process.env.UPSTASH_REDIS_REST_TOKEN ? "redis" : "memory";
}

export async function getAgentState(): Promise<AgentState> {
  if (storageMode() === "redis") {
    const out = await redis(["GET", KEY]);
    if (out?.result) {
      try { return { ...clone(DEFAULT_STATE), ...JSON.parse(out.result) }; } catch {}
    }
    return clone(DEFAULT_STATE);
  }
  globalThis.__siftAgentState ||= clone(DEFAULT_STATE);
  return clone(globalThis.__siftAgentState);
}

export async function setAgentState(state: AgentState) {
  const clean: AgentState = {
    ...state,
    posts: state.posts.slice(0, 120),
    tokenCooldowns: Object.fromEntries(Object.entries(state.tokenCooldowns).filter(([, until]) => until > Date.now() - 86400000)),
  };
  if (storageMode() === "redis") {
    await redis(["SET", KEY, JSON.stringify(clean)]);
  } else {
    globalThis.__siftAgentState = clone(clean);
  }
  return clean;
}
