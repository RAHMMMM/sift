import { client, curveBuyEvent, curveSellEvent } from "@/lib/pons";
import type { Address } from "viem";
import type { WindowStats } from "@/lib/score";

const BPM = BigInt(process.env.RADAR_BLOCKS_PER_MINUTE || "60");
const LOG_BLOCK_SPAN = Number(process.env.RPC_LOG_BLOCK_SPAN || "2000");

export type SerializedWindow = {
  buys: number;
  sells: number;
  uniqueBuyers: number;
  buyVolume: string;
  sellVolume: string;
};

function empty(): WindowStats {
  return { buys: 0, sells: 0, uniqueBuyers: 0, buyVolume: 0n, sellVolume: 0n };
}

export async function readWindowsForCurves(
  curves: Address[],
  launchBlocks: Map<string, bigint>,
  latest: bigint
) {
  const result = new Map<string, { m5: WindowStats; m15: WindowStats; h1: WindowStats }>();
  for (const curve of curves) result.set(curve.toLowerCase(), { m5: empty(), m15: empty(), h1: empty() });
  if (!curves.length) return result;

  const rawFrom = latest > BPM * 60n ? latest - BPM * 60n : 0n;
  const earliestLaunch = [...launchBlocks.values()].reduce((a, b) => (a < b ? a : b), latest);
  const fromBlock = rawFrom > earliestLaunch ? rawFrom : earliestLaunch;

  async function logsFor(event: typeof curveBuyEvent | typeof curveSellEvent) {
    const requests = [];
    const last = Number(latest);
    for (let start = Number(fromBlock); start <= last; start += LOG_BLOCK_SPAN) {
      const end = Math.min(start + LOG_BLOCK_SPAN - 1, last);
      requests.push(client.getLogs({ address: curves, event, fromBlock: BigInt(start), toBlock: BigInt(end) }));
    }
    return (await Promise.all(requests)).flat() as any[];
  }
  const [buys, sells] = await Promise.all([logsFor(curveBuyEvent), logsFor(curveSellEvent)]);

  const cut5 = latest - BPM * 5n;
  const cut15 = latest - BPM * 15n;
  const cut60 = latest - BPM * 60n;
  const buyers5 = new Map<string, Set<string>>();
  const buyers15 = new Map<string, Set<string>>();
  const buyers60 = new Map<string, Set<string>>();

  const ensureSets = (k: string) => {
    if (!buyers5.has(k)) buyers5.set(k, new Set());
    if (!buyers15.has(k)) buyers15.set(k, new Set());
    if (!buyers60.has(k)) buyers60.set(k, new Set());
  };

  for (const log of buys) {
    const key = log.address.toLowerCase();
    const row = result.get(key);
    if (!row) continue;
    ensureSets(key);
    const buyer = (log.args.buyer || "").toLowerCase();
    const q = log.args.quoteIn || 0n;
    if (log.blockNumber >= cut60) { row.h1.buys++; row.h1.buyVolume += q; buyers60.get(key)!.add(buyer); }
    if (log.blockNumber >= cut15) { row.m15.buys++; row.m15.buyVolume += q; buyers15.get(key)!.add(buyer); }
    if (log.blockNumber >= cut5) { row.m5.buys++; row.m5.buyVolume += q; buyers5.get(key)!.add(buyer); }
  }
  for (const log of sells) {
    const key = log.address.toLowerCase();
    const row = result.get(key);
    if (!row) continue;
    const q = log.args.quoteOut || 0n;
    if (log.blockNumber >= cut60) { row.h1.sells++; row.h1.sellVolume += q; }
    if (log.blockNumber >= cut15) { row.m15.sells++; row.m15.sellVolume += q; }
    if (log.blockNumber >= cut5) { row.m5.sells++; row.m5.sellVolume += q; }
  }
  for (const [key, row] of result) {
    row.m5.uniqueBuyers = buyers5.get(key)?.size || 0;
    row.m15.uniqueBuyers = buyers15.get(key)?.size || 0;
    row.h1.uniqueBuyers = buyers60.get(key)?.size || 0;
  }
  return result;
}

export const serializeWindow = (w: WindowStats): SerializedWindow => ({
  buys: w.buys,
  sells: w.sells,
  uniqueBuyers: w.uniqueBuyers,
  buyVolume: w.buyVolume.toString(),
  sellVolume: w.sellVolume.toString(),
});
