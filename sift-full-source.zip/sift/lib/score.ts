export type WindowStats = { buys:number; sells:number; uniqueBuyers:number; buyVolume:bigint; sellVolume:bigint };
export type MomentumInput = {
  m5:WindowStats; m15:WindowStats; h1:WindowStats;
  ageBlocks:number; graduationProgress:number; graduationVelocity:number;
};
const clamp=(n:number,min=0,max=100)=>Math.max(min,Math.min(max,n));
const ratio=(a:number,b:number)=>b<=0?(a>0?2:1):a/b;

export function momentumScore(x:MomentumInput){
  const t5=x.m5.buys+x.m5.sells, t15=x.m15.buys+x.m15.sells;
  const previous10=Math.max(0,t15-t5);
  const tradeAcceleration=clamp(ratio(t5/5,previous10/10)*35);
  const previousBuyerRate=Math.max(0,x.m15.uniqueBuyers-x.m5.uniqueBuyers)/10;
  const buyerAcceleration=clamp(ratio(x.m5.uniqueBuyers/5,previousBuyerRate)*35);
  const buyPressure=clamp((x.m5.buys/Math.max(1,t5))*100);
  const gradVelocity=clamp(x.graduationVelocity*5);
  const freshness=clamp(100-x.ageBlocks/30);
  return Math.round(clamp(
    tradeAcceleration*.25+buyerAcceleration*.20+buyPressure*.20+
    gradVelocity*.15+clamp(x.graduationProgress)*.10+freshness*.10
  ));
}
export function heatLabel(score:number,m5:WindowStats,m15:WindowStats){
  const t5=m5.buys+m5.sells,t15=m15.buys+m15.sells;
  if(score>=85&&t5>=5)return "HEATING";
  if(score>=70)return "MOVING";
  if(t5>0&&t5>=Math.max(2,Math.ceil(t15*.5)))return "EARLY";
  return "QUIET";
}
