import { fileURLToPath } from 'node:url';

// Development must not overwrite production chunks during local verification.
export default function config(phase) {
  return {
    distDir:
      process.env.SIFT_BUILD_DIR ||
      (process.env.VERCEL
        ? '.next'
        : phase === 'phase-development-server'
          ? '.next-dev'
          : '.next-build'),
    outputFileTracingRoot: fileURLToPath(new URL('.', import.meta.url)),
  };
}
