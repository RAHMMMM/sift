const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict'),path=require('node:path');
const ts=require('typescript'),root=path.resolve(__dirname,'..');
const api={},counts={fetch:0,active:0,max:0,images:0,aborted:0};
class TestImage {
 set src(value){this.value=value;if(!value)return;counts.images++;if(value.includes('hung'))return;setTimeout(()=>value.includes('bad')?this.onerror?.():this.onload?.(),10)}
}
const fakeFetch=(url,{signal})=>{
 counts.fetch++;counts.active++;counts.max=Math.max(counts.max,counts.active);
 const token=new URL(url,'http://local').searchParams.get('token');
 if(token==='metadata-hung')return new Promise((resolve,reject)=>signal.addEventListener('abort',()=>{counts.aborted++;counts.active--;reject(Error('aborted'))},{once:true}));
 return new Promise(resolve=>setTimeout(()=>{counts.active--;resolve({ok:true,json:async()=>({logo:token==='missing'?'':`https://images/${token}`,description:'about'})})},15));
};
vm.runInNewContext(ts.transpileModule(fs.readFileSync(root+'/lib/client-token-media.ts','utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020}}).outputText,{exports:api,fetch:fakeFetch,Image:TestImage,AbortController,setTimeout,clearTimeout,Date,Map,Promise,encodeURIComponent});
(async()=>{
 const same=await Promise.all(Array.from({length:12},()=>api.loadTokenMedia('good')));assert.ok(same.every(x=>x.src==='https://images/good'));assert.equal(counts.fetch,1);assert.equal(counts.images,0);
 await Promise.all(Array.from({length:12},(_,i)=>api.loadTokenMedia('good-'+i)));assert.ok(counts.max<=8);
 const bad=await api.loadTokenMedia('bad');assert.equal(bad.src,'https://images/bad');api.rejectTokenImage('bad');assert.equal((await api.loadTokenMedia('bad')).src,'');let n=counts.fetch;await api.loadTokenMedia('bad');assert.equal(counts.fetch,n);
 const missing=await api.loadTokenMedia('missing');assert.equal(missing.src,'');
 const start=Date.now();const hung=await api.loadTokenMedia('metadata-hung');const elapsed=Date.now()-start;
 assert.equal(hung.src,'');assert.ok(elapsed>=7900&&elapsed<8700);assert.equal(counts.aborted,1);
 api.rejectTokenImage('good');assert.equal((await api.loadTokenMedia('good')).src,'');
 console.log(`PASS: shared success, max ${counts.max} concurrent requests, no gateway retries, missing/bad fallback, negative cache, stalled metadata/image deadlines ${elapsed}ms, late DOM image failure`);
})().catch(e=>{console.error(e);process.exitCode=1});
