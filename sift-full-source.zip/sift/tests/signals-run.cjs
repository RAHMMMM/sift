const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict'),ts=require('typescript');
const api={},memory=new Map();let locked=false,fetches=0;
const token='0x'+'1'.repeat(40),base={token,symbol:'TEST',name:'Test',score:60,buyPressure5m:55,graduationProgress:20,windows:{m5:{buys:2,sells:1,uniqueBuyers:3,buyVolume:'1'}}};
let snapshot={rows:[structuredClone(base)],stale:false};
const imports={'@/lib/kv':{acquireLock:async()=>locked?false:(locked=true),releaseLock:async()=>{locked=false},getJson:async k=>memory.has(k)?structuredClone(memory.get(k)):null,setJson:async(k,v)=>memory.set(k,structuredClone(v))},'@/lib/indexer':{readSnapshot:async()=>structuredClone(snapshot)}};
const context={exports:api,require:id=>imports[id],process:{env:{SIGNALS_DRY_RUN:'true',SIFT_PUBLIC_URL:'https://sift.test'}},Date,Number,String,Math,Boolean,Array,Object,BigInt,AbortSignal,crypto:{randomUUID:()=> 'id'},encodeURIComponent,fetch:async()=>{fetches++;throw Error('should not send')}};
vm.runInNewContext(ts.transpileModule(fs.readFileSync('lib/signals.ts','utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText,context);
(async()=>{
 const first=await api.runSignalEvaluation();assert.equal(first.dryRun,true);assert.equal(first.signalsDetected,0);assert.ok(memory.size>0);
 snapshot.rows[0]={...base,score:86,buyPressure5m:78,graduationProgress:25,windows:{m5:{buys:18,sells:2,uniqueBuyers:12,buyVolume:'10'}}};
 const second=await api.runSignalEvaluation();assert.equal(second.dryRun,true);assert.equal(second.signalsDetected,1);assert.equal(second.candidates[0].type,'HEATING');assert.equal(fetches,0);
 context.process.env.SIGNALS_DRY_RUN='false';snapshot.rows[0]={...snapshot.rows[0],score:99,windows:{m5:{buys:30,sells:2,uniqueBuyers:20,buyVolume:'20'}}};
 const failed=await api.runSignalEvaluation();assert.equal(failed.telegramSent,0);assert.ok(failed.errors.length);const state=[...memory.values()][0];assert.equal(Object.keys(state.delivered).length,0);
 console.log('PASS: dry runs persist observations without Telegram traffic, and failed delivery is never marked sent');
})().catch(e=>{console.error(e);process.exitCode=1});
