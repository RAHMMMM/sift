"use client";
import { useEffect, useMemo, useState } from "react";

type Post = { id:string; kind:string; text:string; status:string; createdAt:number; postedAt?:number; tweetId?:string; symbol?:string; score?:number; sourceTweetUrl?:string; error?:string };
type Payload = { state:{enabled:boolean;runCount:number;lastRunAt:number|null;lastPostAt:number|null;lastResult:string|null;posts:Post[]}; storage:string; xConfigured:boolean; autoPost:boolean };

function ago(ts?:number|null) {
  if (!ts) return "never";
  const s = Math.max(1, Math.floor((Date.now()-ts)/1000));
  if (s < 60) return `${s}s ago`;
  const m = Math.floor(s/60); if (m < 60) return `${m}m ago`;
  return `${Math.floor(m/60)}h ago`;
}

export default function AgentPage() {
  const [data,setData] = useState<Payload|null>(null);
  const [busy,setBusy] = useState(false);
  const [tweetUrl,setTweetUrl] = useState("");
  const [tweetText,setTweetText] = useState("");
  const [edits,setEdits] = useState<Record<string,string>>({});
  async function load(){ const r=await fetch("/api/agent/state",{cache:"no-store"}); setData(await r.json()); }
  useEffect(()=>{load(); const i=setInterval(load,15000); return()=>clearInterval(i)},[]);
  const queued = useMemo(()=>data?.state.posts.filter(p=>p.status==="queued")||[],[data]);
  async function run(){setBusy(true);await fetch("/api/agent/run",{method:"POST"});await load();setBusy(false)}
  async function publish(p:Post){setBusy(true);await fetch("/api/agent/publish",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({id:p.id,text:edits[p.id]||p.text})});await load();setBusy(false)}
  async function draftReply(){if(!tweetUrl||!tweetText)return;setBusy(true);await fetch("/api/agent/reply",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({sourceTweetUrl:tweetUrl,sourceText:tweetText})});setTweetUrl("");setTweetText("");await load();setBusy(false)}
  async function toggle(){if(!data)return;await fetch("/api/agent/state",{method:"PATCH",headers:{"Content-Type":"application/json"},body:JSON.stringify({enabled:!data.state.enabled})});await load()}

  return <main className="agent-shell">
    <header className="agent-head">
      <div><a className="agent-back" href="/">← SIFT MARKET</a><h1>SIFT <span>AGENT</span></h1><p>Autonomous market intelligence distribution.</p></div>
      <div className="agent-actions"><button className="agent-secondary" onClick={toggle}>{data?.state.enabled?"Pause agent":"Resume agent"}</button><button className="agent-primary" onClick={run} disabled={busy}>{busy?"Working…":"Run now"}</button></div>
    </header>

    <section className="agent-grid">
      <div className="agent-stat"><label>AGENT</label><strong className={data?.state.enabled?"on":"off"}>{data?.state.enabled?"ACTIVE":"PAUSED"}</strong><span>checks every 2h via cron</span></div>
      <div className="agent-stat"><label>X CONNECTION</label><strong>{data?.xConfigured?"CONNECTED":"SETUP NEEDED"}</strong><span>{data?.autoPost?"auto-post enabled":"approval mode"}</span></div>
      <div className="agent-stat"><label>STATE</label><strong>{data?.storage?.toUpperCase()||""}</strong><span>{data?.storage==="memory"?"add Redis before production":"persistent"}</span></div>
      <div className="agent-stat"><label>LAST RUN</label><strong>{ago(data?.state.lastRunAt)}</strong><span>{data?.state.lastResult||"waiting"}</span></div>
    </section>

    <section className="agent-section">
      <div className="agent-title"><div><small>01 / CONTENT ENGINE</small><h2>Approval queue</h2></div><span>{queued.length} queued</span></div>
      <div className="queue">
      {queued.length===0?<div className="agent-empty">Nothing waiting. Run the agent to evaluate the live SIFT feed.</div>:queued.map(p=><article className="queue-card" key={p.id}>
        <div className="queue-meta"><span>{p.kind.toUpperCase()}</span><span>{ago(p.createdAt)}</span>{p.symbol&&<span>${p.symbol} · {p.score}</span>}</div>
        <textarea value={edits[p.id]??p.text} onChange={e=>setEdits(v=>({...v,[p.id]:e.target.value}))}/>
        <div className="queue-foot"><span>{(edits[p.id]??p.text).length}/280</span><button className="agent-primary" disabled={busy||!data?.xConfigured} onClick={()=>publish(p)}>{p.kind==="reply"?"Approve & reply":"Approve & post"}</button></div>
      </article>)}
      </div>
    </section>

    <section className="agent-section">
      <div className="agent-title"><div><small>02 / ENGAGEMENT DESK</small><h2>Draft a contextual reply</h2></div><span>human approval required</span></div>
      <div className="reply-box">
        <input value={tweetUrl} onChange={e=>setTweetUrl(e.target.value)} placeholder="Paste X post URL"/>
        <textarea value={tweetText} onChange={e=>setTweetText(e.target.value)} placeholder="Paste the post text. SIFT will match mentioned tokens against the live feed."/>
        <button className="agent-secondary" disabled={busy||!tweetUrl||!tweetText} onClick={draftReply}>Generate reply</button>
      </div>
    </section>

    <section className="agent-section">
      <div className="agent-title"><div><small>03 / HISTORY</small><h2>Agent activity</h2></div><span>{data?.state.posts.length||0} events</span></div>
      <div className="history">
      {(data?.state.posts||[]).slice(0,20).map(p=><div className="history-row" key={p.id}><span className={`history-status ${p.status}`}>{p.status}</span><span>{p.kind}</span><b>{p.symbol?`$${p.symbol}`:"SIFT"}</b><span>{ago(p.postedAt||p.createdAt)}</span>{p.error&&<em>{p.error}</em>}</div>)}
      </div>
    </section>
  </main>
}
