import { NextResponse } from 'next/server';
export const dynamic = 'force-dynamic';
export const maxDuration = 30;

export async function GET(request: Request) {
  const cidPath = new URL(request.url).searchParams.get('cid') || '';
  if (!/^(Qm[1-9A-HJ-NP-Za-km-z]{44}|b[a-z2-7]{20,})(\/[A-Za-z0-9._~!$&'()*+,;=:@%-]+)*$/.test(cidPath)) return new NextResponse(null, { status: 400 });
  const sources = [`https://ipfs.io/ipfs/${cidPath}`, `https://gateway.pinata.cloud/ipfs/${cidPath}`];
  for (const source of sources) {
    try {
      const response = await fetch(source, { signal: AbortSignal.timeout(12_000), redirect: 'follow' });
      if (!response.ok) continue;
      const type = response.headers.get('content-type') || '';
      if (!type.startsWith('image/')) continue;
      return new NextResponse(await response.arrayBuffer(), { headers: { 'Content-Type': type, 'Cache-Control': 'public, s-maxage=86400, stale-while-revalidate=604800' } });
    } catch {}
  }
  return new NextResponse(null, { status: 502, headers: { 'Cache-Control': 'public, s-maxage=60' } });
}
