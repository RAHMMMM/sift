import { NextResponse } from "next/server";
import { getAgentState, setAgentState, storageMode } from "@/lib/agent-store";
import { xConfigured } from "@/lib/x-client";

export const dynamic = "force-dynamic";
export async function GET() {
  const state = await getAgentState();
  return NextResponse.json({ state, storage: storageMode(), xConfigured: xConfigured(), autoPost: process.env.X_AUTO_POST === "true" });
}
export async function PATCH(req: Request) {
  const body = await req.json().catch(() => ({}));
  const state = await getAgentState();
  if (typeof body.enabled === "boolean") state.enabled = body.enabled;
  await setAgentState(state);
  return NextResponse.json({ state });
}
