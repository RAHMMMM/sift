import { NextResponse } from "next/server";
import { getAgentState, setAgentState } from "@/lib/agent-store";
import { createTweet, tweetIdFromUrl } from "@/lib/x-client";

export async function POST(req: Request) {
  const { id, text } = await req.json();
  const state = await getAgentState();
  const post = state.posts.find(p => p.id === id);
  if (!post) return NextResponse.json({ error: "Post not found" }, { status: 404 });
  if (post.status === "posted") return NextResponse.json({ error: "Already posted" }, { status: 409 });
  if (typeof text === "string" && text.trim()) post.text = text.trim().slice(0, 280);
  try {
    const replyTo = post.kind === "reply" && post.sourceTweetUrl ? tweetIdFromUrl(post.sourceTweetUrl) : undefined;
    const tweet = await createTweet(post.text, replyTo || undefined);
    post.status = "posted";
    post.postedAt = Date.now();
    post.tweetId = tweet.id;
    state.lastPostAt = post.postedAt;
    if (post.token) state.tokenCooldowns[post.token.toLowerCase()] = Date.now() + Number(process.env.AGENT_TOKEN_COOLDOWN_HOURS || "8") * 3600000;
    state.lastResult = `Published ${post.kind}`;
    await setAgentState(state);
    return NextResponse.json({ ok: true, post });
  } catch (e) {
    post.status = "failed";
    post.error = e instanceof Error ? e.message : "Publish failed";
    await setAgentState(state);
    return NextResponse.json({ error: post.error }, { status: 500 });
  }
}
