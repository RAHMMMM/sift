import { NextResponse } from "next/server";
import { getAgentState, setAgentState } from "@/lib/agent-store";
import { generateReply } from "@/lib/social-agent";

export async function POST(req: Request) {
  const { sourceTweetUrl, sourceText } = await req.json();
  if (!sourceTweetUrl || !sourceText) return NextResponse.json({ error: "Tweet URL and text are required" }, { status: 400 });
  const base = process.env.SIFT_PUBLIC_URL || new URL(req.url).origin;
  const feedRes = await fetch(`${base}/api/trending`, { cache: "no-store" });
  const feed = await feedRes.json();
  const post = generateReply(String(sourceText), String(sourceTweetUrl), Array.isArray(feed.rows) ? feed.rows : []);
  const state = await getAgentState();
  state.posts.unshift(post);
  state.lastResult = "Reply drafted for approval";
  await setAgentState(state);
  return NextResponse.json({ ok: true, post });
}
