import { NextResponse } from "next/server";
import { getAgentState, setAgentState } from "@/lib/agent-store";
import { generatePost } from "@/lib/social-agent";
import { createTweet, xConfigured } from "@/lib/x-client";

export const dynamic = "force-dynamic";

function authorized(req: Request) {
  const secret = process.env.CRON_SECRET;
  if (!secret) return true;
  return req.headers.get("authorization") === `Bearer ${secret}`;
}

function origin(req: Request) {
  return process.env.SIFT_PUBLIC_URL || new URL(req.url).origin;
}

async function execute(req: Request) {
  if (!authorized(req)) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const state = await getAgentState();
  state.lastRunAt = Date.now();
  state.runCount += 1;
  if (!state.enabled) {
    state.lastResult = "Agent disabled";
    await setAgentState(state);
    return NextResponse.json({ ok: true, skipped: true, reason: state.lastResult });
  }

  try {
    const feedRes = await fetch(`${origin(req)}/api/trending`, { cache: "no-store" });
    const feed = await feedRes.json();
    if (!feedRes.ok || feed.stale || !Array.isArray(feed.rows) || !feed.rows.length) {
      state.lastResult = feed.stale ? "Skipped: market feed is stale" : "Skipped: no live market rows";
      await setAgentState(state);
      return NextResponse.json({ ok: true, skipped: true, reason: state.lastResult });
    }

    const post = generatePost(feed.rows, state);
    if (!post) {
      state.lastResult = "Skipped: no meaningful signal";
      await setAgentState(state);
      return NextResponse.json({ ok: true, skipped: true, reason: state.lastResult });
    }

    const minGap = Number(process.env.AGENT_MIN_POST_GAP_MINUTES || "90") * 60_000;
    if (state.lastPostAt && Date.now() - state.lastPostAt < minGap) {
      state.lastResult = "Skipped: post cooldown active";
      await setAgentState(state);
      return NextResponse.json({ ok: true, skipped: true, reason: state.lastResult });
    }

    const auto = process.env.X_AUTO_POST === "true" && xConfigured();
    if (auto) {
      const tweet = await createTweet(post.text);
      post.status = "posted";
      post.tweetId = tweet.id;
      post.postedAt = Date.now();
      state.lastPostAt = post.postedAt;
      if (post.token) state.tokenCooldowns[post.token.toLowerCase()] = Date.now() + Number(process.env.AGENT_TOKEN_COOLDOWN_HOURS || "8") * 3600000;
      state.lastResult = `Posted ${post.kind}`;
    } else {
      state.lastResult = `Queued ${post.kind} for approval`;
    }
    state.posts.unshift(post);
    await setAgentState(state);
    return NextResponse.json({ ok: true, autoPosted: auto, post });
  } catch (e) {
    state.lastResult = `Failed: ${e instanceof Error ? e.message : "unknown error"}`;
    await setAgentState(state);
    return NextResponse.json({ error: state.lastResult }, { status: 500 });
  }
}

export async function GET(req: Request) { return execute(req); }
export async function POST(req: Request) { return execute(req); }
