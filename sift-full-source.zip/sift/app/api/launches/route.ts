import { NextResponse } from "next/server";
import { getRecentLaunches } from "@/lib/pons";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const launches = await getRecentLaunches();
    return NextResponse.json(
      launches.map((x) => ({
        ...x,
        blockNumber: x.blockNumber.toString(),
      }))
    );
  } catch (error) {
    return NextResponse.json(
      { error: "Live Pons launch data is temporarily unavailable." },
      { status: 500 }
    );
  }
}
