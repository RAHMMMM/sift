import { NextResponse } from 'next/server';
import { tokenMedia } from '@/lib/token-media';
import type { Address } from 'viem';

export async function GET(request: Request) {
  const token = new URL(request.url).searchParams.get('token') || '';
  if (!/^0x[0-9a-fA-F]{40}$/.test(token)) return NextResponse.json({ error: 'Invalid token' }, { status: 400 });
  const value = await tokenMedia(token as Address);
  const cidPath = value.logo.match(/\/ipfs\/([^?#]+)/)?.[1];
  const logo = cidPath ? `/api/token-image?cid=${encodeURIComponent(cidPath)}` : value.logo;
  return NextResponse.json({ ...value, logo }, { headers: { 'Cache-Control': `public, max-age=${value.logo ? 3600 : 300}` } });
}
