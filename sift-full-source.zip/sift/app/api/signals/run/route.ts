import { NextResponse } from 'next/server';
import { runSignalEvaluation } from '@/lib/signals';
import { advanceIndex } from '@/lib/indexer';
export const dynamic='force-dynamic';export const maxDuration=60;
function authorized(req:Request){const supplied=req.headers.get('authorization');const secrets=[process.env.SIGNALS_CRON_SECRET,process.env.CRON_SECRET].filter(Boolean);return secrets.some(secret=>supplied===`Bearer ${secret}`);}
async function execute(req:Request){if(!authorized(req))return NextResponse.json({error:process.env.SIGNALS_CRON_SECRET?'Unauthorized':'SIGNALS_CRON_SECRET is not configured'},{status:process.env.SIGNALS_CRON_SECRET?401:503});try{await advanceIndex();return NextResponse.json(await runSignalEvaluation());}catch(e){return NextResponse.json({error:e instanceof Error?e.message:'Signal evaluation failed'},{status:500});}}
export async function GET(req:Request){return execute(req)}export async function POST(req:Request){return execute(req)}
