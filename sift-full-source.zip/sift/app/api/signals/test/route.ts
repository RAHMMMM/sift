import { NextResponse } from 'next/server';
import { sendTelegramTest } from '@/lib/signals';
export const dynamic='force-dynamic';
export async function POST(req:Request){const secret=process.env.SIGNALS_CRON_SECRET;if(!secret||req.headers.get('authorization')!==`Bearer ${secret}`)return NextResponse.json({error:secret?'Unauthorized':'SIGNALS_CRON_SECRET is not configured'},{status:secret?401:503});try{const messageId=await sendTelegramTest();return NextResponse.json({ok:true,messageId});}catch(e){return NextResponse.json({error:e instanceof Error?e.message:'Telegram test failed'},{status:500});}}
