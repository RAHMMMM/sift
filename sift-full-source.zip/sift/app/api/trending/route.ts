import { after, NextResponse } from "next/server";
import { advanceIndex, readSnapshot, type FeedSnapshot } from "@/lib/indexer";

export const dynamic = "force-dynamic";
export const maxDuration = 60;
const CACHE_HEADERS = { "Cache-Control": "public, s-maxage=30, stale-while-revalidate=300" };
let localRefresh: Promise<FeedSnapshot | null> | null = null;
const refresh = () => localRefresh ||= advanceIndex().finally(() => { localRefresh = null; });

export async function GET() {
  try {
    const snapshot = await readSnapshot();
    if (snapshot) {
      after(async () => { try { await refresh(); } catch {} });
      return NextResponse.json(snapshot, { headers: CACHE_HEADERS });
    }
    const first = await refresh();
    if (first) return NextResponse.json(first, { headers: CACHE_HEADERS });
    return NextResponse.json({ rows: [], updatedAt: Date.now(), stale: true, warning: "Onchain index is starting." }, { headers: CACHE_HEADERS });
  } catch (error) {
    const diagnostic = error instanceof Error ? error.message.replace(/https?:\/\/\S+/g, "[credential URL redacted]") : "Unknown index error";
    console.error("SIFT index refresh failed:", diagnostic);
    const fallback = await readSnapshot().catch(() => null);
    if (fallback) return NextResponse.json({ ...fallback, stale: true, warning: "Indexer refresh delayed; showing the last successful snapshot." }, { headers: CACHE_HEADERS });
    return NextResponse.json({ rows: [], error: "Market index is temporarily unavailable." }, { status: 503, headers: { "Cache-Control": "no-store" } });
  }
}
