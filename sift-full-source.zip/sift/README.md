# SIFT v1.0 Launch Candidate

This build locks the preferred SIFT interface and keeps the latest functional work: 100-market feed, progressive rendering, mobile cards, token drawer, SIFT Agent, X integration hooks, cron support, and persistent-state support.

## PFP strategy
Token images no longer pass through the local `/api/image` proxy. Visible images load directly from the token metadata source with timed fallback across IPFS gateways. Off-screen market images are deferred until they approach the viewport. A ticker fallback appears after all image candidates fail.

## Run
```bash
cp .env.example .env.local
npm install
npm run dev
```

Open `/` for SIFT and `/agent` for the agent control room.

## Telegram signals

The Telegram signal engine reuses the durable SIFT snapshot and Upstash storage; it never runs a second chain indexer. Configure `TELEGRAM_BOT_TOKEN`, `TELEGRAM_CHAT_ID`, `TELEGRAM_SIGNAL_THREAD_ID`, and `SIGNALS_CRON_SECRET` in Vercel. Every send includes the Signals forum topic's `message_thread_id`, so alerts cannot fall into General. Leave `SIGNALS_DRY_RUN=true` while tuning.

Run an evaluation with `POST /api/signals/run` and `Authorization: Bearer <SIGNALS_CRON_SECRET>`. The first run establishes persistent baselines; later runs compare real observations. Send one connection check with `POST /api/signals/test` using the same authorization header.

No frequent Vercel cron is configured because plan schedules vary. Use a five-minute external HTTPS scheduler against the protected run endpoint, with overlapping runs deduplicated by the Upstash lock. Set `SIGNALS_DRY_RUN=false` only after reviewing candidate output. Telegram execution is isolated from the existing X approval workflow.
